MEXC Bot Mobile & API Backend Package (auto-generated)
=====================================================

- build_and_package.sh: Builds the Flutter Android APK if flutter is installed/available, else packages sources.
- backend/: A secure python fastapi scaffold implementing master key encryption using AES-GCM and CCXT for checking MEXC API.
- flutter_app/: Flutter interface to input credentials, test connectivity, and sync with the bot system.

To build APK locally:
1. Ensure Flutter & Android SDK are installed.
2. Run build_and_package.sh on your Linux/Mac machine.
