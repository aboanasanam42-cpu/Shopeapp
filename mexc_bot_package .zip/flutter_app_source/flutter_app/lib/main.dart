import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext ctx) => MaterialApp(
    title: 'MEXC Bot',
    theme: ThemeData(
      primarySwatch: Colors.deepPurple,
      brightness: Brightness.dark,
    ),
    home: CredsPage(),
  );
}

class CredsPage extends StatefulWidget { 
  @override 
  _CredsPageState createState() => _CredsPageState(); 
}

class _CredsPageState extends State<CredsPage> {
  final _apiKeyController = TextEditingController();
  final _apiSecretController = TextEditingController();
  String _status = '';

  Future<void> testConnection() async {
    final apiKey = _apiKeyController.text.trim();
    final apiSecret = _apiSecretController.text.trim();
    if (apiKey.isEmpty || apiSecret.isEmpty) { 
      setState(() => _status = 'أدخل API Key و Secret'); 
      return; 
    }
    setState(() => _status = 'جارٍ الإختبار...');
    try {
      final resp = await http.post(
        Uri.parse('http://127.0.0.1:8000/credentials/mexc/test'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'api_key': apiKey, 'api_secret': apiSecret}),
      );
      if (resp.statusCode == 200) {
        setState(() => _status = 'نجح الاتصال بنجاح!');
      } else {
        setState(() => _status = 'فشل الاتصال بالمنصة: ${resp.body}');
      }
    } catch (e) { 
      setState(() => _status = 'خطأ اتصال: $e'); 
    }
  }

  @override 
  void dispose() { 
    _apiKeyController.dispose(); 
    _apiSecretController.dispose(); 
    super.dispose(); 
  }

  @override 
  Widget build(BuildContext ctx) {
    return Scaffold(
      appBar: AppBar(title: Text('MEXC Bot Control Hub')),
      body: Padding(
        padding: EdgeInsets.all(16), 
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'لوحة التحكم وتفعيل التداول اليدوية والمقيدة لـ MEXC Bot',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.amber),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 16),
            TextField(
              controller: _apiKeyController, 
              decoration: InputDecoration(
                labelText: 'MEXC API Key (الرئيسي)',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 12),
            TextField(
              controller: _apiSecretController, 
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'MEXC Secret Key',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: testConnection, 
              style: ElevatedButton.styleFrom(primary: Colors.amber, onPrimary: Colors.black),
              child: Text('إختبار وتعميم الإتصال بالمنفذ الفعلي 🔌'),
            ),
            SizedBox(height: 16),
            Card(
              color: Colors.grey[900],
              child: Padding(
                padding: EdgeInsets.all(12),
                child: Text(
                  _status,
                  style: TextStyle(fontSize: 13, fontFamily: 'monospace', color: Colors.greenAccent),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
