Security Guidelines
===================

1. Do NOT put live API keys or secrets into repositories, public chats, or logs.
2. The MASTER_KEY should be randomly generated (e.g. 32 bytes base64 decoded) and kept secret on your server.
3. Keep the backend in a restricted VPC or require authentication before calling API endpoints.
