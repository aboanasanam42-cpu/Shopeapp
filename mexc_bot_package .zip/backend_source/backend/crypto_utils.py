import os, base64
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

def encrypt_secret(master_key_b64: str, plaintext: str) -> str:
    master_key = base64.b64decode(master_key_b64)
    aesgcm = AESGCM(master_key)
    nonce = os.urandom(12)
    ct = aesgcm.encrypt(nonce, plaintext.encode(), None)
    return base64.b64encode(nonce + ct).decode()
