from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import os
import ccxt.async_support as ccxt
from crypto_utils import encrypt_secret

MASTER_KEY = os.getenv("MASTER_KEY", "bXlfdGVtcF9tYXN0ZXJfY29kZV9rZXlfMzJfYnl0ZXM9PQ==") # Standard fallback if not loaded
app = FastAPI(title="MEXC Secure API Client wrapper pod")

class Creds(BaseModel):
    api_key: str
    api_secret: str

@app.post("/credentials/mexc/test")
async def test_creds(creds: Creds):
    if not MASTER_KEY:
        raise HTTPException(status_code=500, detail="MASTER_KEY not set")
    try:
        ex = ccxt.mexc({'apiKey': creds.api_key, 'secret': creds.api_secret, 'enableRateLimit': True})
        await ex.load_markets()
        bal = await ex.fetch_balance()
        await ex.close()
        encrypted = encrypt_secret(MASTER_KEY, creds.api_secret)
        return {
            "ok": True, 
            "balances": bal.get('total', {}), 
            "encrypted_sample": encrypted[:20] + "..."
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/health")
def health(): 
    return {"status": "ok"}
