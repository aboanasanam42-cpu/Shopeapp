#!/usr/bin/env bash
# ==============================================================================
# Palace P2P - Git Initialization and GitHub Remote Push Automation Script
# Compatible with Linux, macOS, and Git Bash on Windows
# ==============================================================================

set -e

echo ""
echo "🏰 ======================================================"
echo "   Palace P2P - Setup & Automated GitHub Repository Push"
echo "=========================================================="
echo ""

# 1. Ensure Git is available
if ! command -v git &> /dev/null; then
    echo "❌ Error: git is not installed. Please install Git and try again."
    exit 1
fi

# 2. Setup clean Flutter & Android .gitignore if not present
if [ ! -f ".gitignore" ]; then
    echo "📝 Generating clean .gitignore..."
    cat << 'EOF' > .gitignore
# Miscellaneous
*.class
*.log
*.pyc
*.swp
.DS_Store
.atom/
.buildlog/
.history
.svn/
migrate_working_dir/

# IntelliJ related
*.iml
*.ipr
*.iws
.idea/

# Android Studio / Android
/android/local.properties
/android/.gradle
/android/captures/
/android/gradlew
/android/gradlew.bat
/android/app/build/
/android/build/
.gradle/
build/
app/build/

# Flutter specific
.dart_tool/
.flutter-plugins
.flutter-plugins-dependencies
.packages
.pub-cache/
.pub/
/build/
EOF
fi

# 3. Initialize Git Repository
if [ ! -d ".git" ]; then
    echo "🔧 Initializing new Git repository..."
    git init -b main || git init
    git branch -M main 2>/dev/null || true
else
    echo "ℹ️ Existing Git repository detected."
    git branch -M main 2>/dev/null || true
fi

# 4. Stage and commit all files
echo "📦 Staging and committing project files..."
git add .
git commit -m "feat: complete Palace P2P 2D Local Multiplayer game with offline sync & proximity triggers" || echo "ℹ️ Working tree clean, nothing new to commit."

# 5. Prompt for GitHub Remote URL
echo ""
echo "🔗 GitHub Remote Configuration:"
echo "----------------------------------------------------------"
echo "Default repository detected: https://github.com/aboanasanam42-cpu/wife.git"
echo "Press ENTER to push to this repository, or enter a different URL."
echo "----------------------------------------------------------"
read -rp "Enter GitHub Remote URL [default: https://github.com/aboanasanam42-cpu/wife.git]: " REMOTE_URL

if [ -z "$REMOTE_URL" ]; then
    REMOTE_URL="https://github.com/aboanasanam42-cpu/wife.git"
fi

# Set origin remote
if git remote | grep -q "origin"; then
    git remote set-url origin "$REMOTE_URL"
else
    git remote add origin "$REMOTE_URL"
fi

echo "🚀 Pushing codebase to origin/main..."
git push -u origin main

echo ""
echo "🎉 SUCCESS! Your Palace P2P game has been pushed to GitHub!"
echo "✨ If you configured GitHub Actions (.github/workflows/build_apk.yml),"
echo "   your APK will automatically build and be ready for your Android 15 devices!"
echo "=========================================================="
