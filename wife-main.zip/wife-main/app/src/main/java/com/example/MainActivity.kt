package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.network.LocalP2PManager
import com.example.ui.screens.GameScreen
import com.example.ui.screens.LobbyScreen
import com.example.ui.screens.PushGuideScreen
import com.example.ui.theme.MyApplicationTheme

enum class ScreenState {
    LOBBY,
    GAME,
    PUSH_GUIDE
}

class MainActivity : ComponentActivity() {

    private val p2pManager = LocalP2PManager()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                PalaceApp(p2pManager = p2pManager)
            }
        }
    }

    override fun onDestroy() {
        p2pManager.disconnect()
        super.onDestroy()
    }
}

@Composable
fun PalaceApp(p2pManager: LocalP2PManager) {
    var currentScreen by remember { mutableStateOf(ScreenState.LOBBY) }
    var activePlayerName by remember { mutableStateOf("Player") }

    when (currentScreen) {
        ScreenState.LOBBY -> {
            LobbyScreen(
                p2pManager = p2pManager,
                onStartGame = { name ->
                    activePlayerName = name
                    currentScreen = ScreenState.GAME
                },
                onOpenPushGuide = {
                    currentScreen = ScreenState.PUSH_GUIDE
                }
            )
        }
        ScreenState.GAME -> {
            GameScreen(
                p2pManager = p2pManager,
                localPlayerName = activePlayerName,
                onExitGame = {
                    currentScreen = ScreenState.LOBBY
                }
            )
        }
        ScreenState.PUSH_GUIDE -> {
            PushGuideScreen(
                onBack = {
                    currentScreen = ScreenState.LOBBY
                }
            )
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    MyApplicationTheme { Greeting("Android") }
}
