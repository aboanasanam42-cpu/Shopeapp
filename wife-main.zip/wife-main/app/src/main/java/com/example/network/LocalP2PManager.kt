package com.example.network

import android.util.Log
import com.example.model.HeartbeatPayload
import com.example.model.InteractionPayload
import com.example.model.MovementPayload
import com.example.model.PacketModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import kotlin.random.Random

enum class PeerState {
    DISCONNECTED,
    HOSTING,
    CONNECTING,
    CONNECTED
}

class LocalP2PManager {

    companion object {
        const val PORT = 8888
        private const val TAG = "LocalP2PManager"
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _connectionState = MutableStateFlow(PeerState.DISCONNECTED)
    val connectionState: StateFlow<PeerState> = _connectionState

    private val _latencyMs = MutableStateFlow(0)
    val latencyMs: StateFlow<Int> = _latencyMs

    private val _partnerName = MutableStateFlow("Partner")
    val partnerName: StateFlow<String> = _partnerName

    private val _movementFlow = MutableSharedFlow<MovementPayload>(extraBufferCapacity = 64)
    val movementFlow: SharedFlow<MovementPayload> = _movementFlow

    private val _interactionFlow = MutableSharedFlow<InteractionPayload>(extraBufferCapacity = 16)
    val interactionFlow: SharedFlow<InteractionPayload> = _interactionFlow

    private var serverSocket: ServerSocket? = null
    private var activeSocket: Socket? = null
    private var socketWriter: PrintWriter? = null
    private var readJob: Job? = null
    private var heartbeatJob: Job? = null

    var isSoloCompanionMode = false
        private set
    private var companionJob: Job? = null

    fun getLocalIpAddress(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        return addr.hostAddress ?: "127.0.0.1"
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting IP", e)
        }
        return "127.0.0.1"
    }

    fun startHosting(roomName: String) {
        disconnect()
        isSoloCompanionMode = false
        _connectionState.value = PeerState.HOSTING

        scope.launch {
            try {
                serverSocket = ServerSocket(PORT)
                Log.d(TAG, "Server listening on port $PORT")
                val client = serverSocket!!.accept()
                activeSocket = client
                setupSocketIO(client, "Guest")
            } catch (e: Exception) {
                Log.e(TAG, "Host server exception", e)
                if (_connectionState.value == PeerState.HOSTING) {
                    _connectionState.value = PeerState.DISCONNECTED
                }
            }
        }
    }

    fun connectToHost(hostIp: String) {
        disconnect()
        isSoloCompanionMode = false
        _connectionState.value = PeerState.CONNECTING

        scope.launch {
            try {
                val socket = Socket(hostIp, PORT)
                activeSocket = socket
                setupSocketIO(socket, "Host Ruler")
            } catch (e: Exception) {
                Log.e(TAG, "Client connect exception", e)
                _connectionState.value = PeerState.DISCONNECTED
            }
        }
    }

    fun startSoloCompanionMode() {
        disconnect()
        isSoloCompanionMode = true
        _partnerName.value = "Princess Luna (AI)"
        _connectionState.value = PeerState.CONNECTED

        // Spawn a gentle companion that roams around the palace zones
        companionJob = scope.launch {
            var compX = 220f
            var compY = 200f
            var targetX = 250f
            var targetY = 220f
            var moveTimer = 0

            while (isActive && isSoloCompanionMode) {
                delay(50)
                moveTimer++
                if (moveTimer > 60) {
                    moveTimer = 0
                    targetX = 100f + Random.nextFloat() * 250f
                    targetY = 100f + Random.nextFloat() * 300f
                }
                compX += (targetX - compX) * 0.05f
                compY += (targetY - compY) * 0.05f

                _movementFlow.tryEmit(
                    MovementPayload(
                        x = compX,
                        y = compY,
                        dir = if (targetX > compX) "right" else "left"
                    )
                )
            }
        }
    }

    private fun setupSocketIO(socket: Socket, defaultPartner: String) {
        _partnerName.value = defaultPartner
        _connectionState.value = PeerState.CONNECTED

        socketWriter = PrintWriter(socket.getOutputStream(), true)
        val reader = BufferedReader(InputStreamReader(socket.getInputStream()))

        readJob = scope.launch {
            try {
                while (isActive) {
                    val line = reader.readLine() ?: break
                    val packet = PacketModel.deserialize(line) ?: continue

                    when (packet) {
                        is MovementPayload -> _movementFlow.emit(packet)
                        is InteractionPayload -> _interactionFlow.emit(packet)
                        is HeartbeatPayload -> {
                            val now = System.currentTimeMillis()
                            _latencyMs.value = (now - packet.timestamp).toInt().coerceAtLeast(1)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.d(TAG, "Socket reader closed")
            } finally {
                disconnect()
            }
        }

        // Heartbeat every 2s
        heartbeatJob = scope.launch {
            while (isActive) {
                delay(2000)
                sendPacket(HeartbeatPayload(timestamp = System.currentTimeMillis()))
            }
        }
    }

    fun sendMovement(x: Float, y: Float, dir: String) {
        sendPacket(MovementPayload(x = x, y = y, dir = dir))
    }

    fun sendInteraction(actionId: String, zone: String, status: String, timerSeconds: Int? = null) {
        sendPacket(InteractionPayload(actionId = actionId, zone = zone, status = status, timerSeconds = timerSeconds))

        if (isSoloCompanionMode && status == "REQUEST") {
            // Companion automatically accepts after 1 second
            scope.launch {
                delay(1200)
                _interactionFlow.emit(
                    InteractionPayload(
                        actionId = actionId,
                        zone = zone,
                        status = "ACCEPT",
                        timerSeconds = timerSeconds
                    )
                )
            }
        }
    }

    private fun sendPacket(packet: PacketModel) {
        if (isSoloCompanionMode) return
        scope.launch {
            try {
                socketWriter?.println(packet.serialize())
            } catch (e: Exception) {
                Log.e(TAG, "Error sending packet", e)
            }
        }
    }

    fun disconnect() {
        readJob?.cancel()
        readJob = null
        heartbeatJob?.cancel()
        heartbeatJob = null
        companionJob?.cancel()
        companionJob = null

        try {
            socketWriter?.close()
            socketWriter = null
            activeSocket?.close()
            activeSocket = null
            serverSocket?.close()
            serverSocket = null
        } catch (e: Exception) {
            Log.e(TAG, "Disconnect error", e)
        }

        _connectionState.value = PeerState.DISCONNECTED
        _latencyMs.value = 0
    }
}
