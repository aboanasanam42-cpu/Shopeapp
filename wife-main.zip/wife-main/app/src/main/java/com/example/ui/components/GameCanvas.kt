package com.example.ui.components

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import com.example.game.PalaceGameEngine
import com.example.game.ZoneDefinitions
import kotlin.math.sin

@Composable
fun GameCanvas(
    engine: PalaceGameEngine,
    localPlayerName: String,
    remotePlayerName: String,
    isArabic: Boolean = true,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Background / Palace Stone Walls
        drawRect(color = Color(0xFF0F0B18))

        // 1. Render Zones
        renderZones(w, h, isArabic)

        // 2. Render Proximity Tether Aura if in range (R <= 50)
        if (engine.isWithinProximity) {
            // Proximity connecting laser/beam
            drawLine(
                brush = Brush.linearGradient(
                    colors = listOf(Color(0xFFEC4899), Color(0xFF8B5CF6))
                ),
                start = Offset(engine.localX, engine.localY),
                end = Offset(engine.remoteX, engine.remoteY),
                strokeWidth = 4f
            )

            // Pulsing proximity circles around players
            drawCircle(
                color = Color(0x33EC4899),
                radius = PalaceGameEngine.PROXIMITY_RADIUS,
                center = Offset(engine.localX, engine.localY)
            )
            drawCircle(
                color = Color(0x66EC4899),
                radius = PalaceGameEngine.PROXIMITY_RADIUS,
                center = Offset(engine.localX, engine.localY),
                style = Stroke(width = 2f)
            )
        }

        // 3. Render Floating Heart Particles
        for (p in engine.particles) {
            drawCircle(
                color = Color(0xFFF43F5E).copy(alpha = p.alpha),
                radius = p.size,
                center = Offset(p.x, p.y)
            )
            drawCircle(
                color = Color.White.copy(alpha = p.alpha * 0.8f),
                radius = p.size * 0.4f,
                center = Offset(p.x - p.size * 0.2f, p.y - p.size * 0.2f)
            )
        }

        // 4. Render Remote Player
        val remoteTag = if (isArabic) "$remotePlayerName (شريك الروح)" else "$remotePlayerName (P2P)"
        renderCharacter(
            x = engine.remoteX,
            y = engine.remoteY,
            direction = engine.remoteDir,
            name = remoteTag,
            color = Color(0xFFEC4899),
            crownColor = Color(0xFFFDE047),
            emote = engine.remoteEmote
        )

        // 5. Render Local Player
        val localTag = if (isArabic) "$localPlayerName (أنت)" else "$localPlayerName (You)"
        renderCharacter(
            x = engine.localX,
            y = engine.localY,
            direction = engine.localDir,
            name = localTag,
            color = Color(0xFF8B5CF6),
            crownColor = Color(0xFFF59E0B),
            emote = engine.localEmote
        )
    }
}

private fun DrawScope.renderZones(w: Float, h: Float, isArabic: Boolean = true) {
    val gardenBounds = ZoneDefinitions.getGardenBounds(w, h)
    val livingBounds = ZoneDefinitions.getLivingRoomBounds(w, h)
    val bedroomBounds = ZoneDefinitions.getBedroomBounds(w, h)

    // === GARDEN ===
    drawRoundRect(
        color = Color(0xFF132A13),
        topLeft = Offset(gardenBounds.left, gardenBounds.top),
        size = Size(gardenBounds.width, gardenBounds.height),
        cornerRadius = CornerRadius(16f, 16f)
    )
    drawRoundRect(
        color = Color(0xFF31572C),
        topLeft = Offset(gardenBounds.left, gardenBounds.top),
        size = Size(gardenBounds.width, gardenBounds.height),
        cornerRadius = CornerRadius(16f, 16f),
        style = Stroke(width = 3f)
    )

    // Garden Fountain in Center
    val fountainCenter = Offset(gardenBounds.center.x, gardenBounds.center.y)
    drawCircle(color = Color(0xFF1D3557), radius = 42f, center = fountainCenter)
    drawCircle(color = Color(0xFF457B9D), radius = 32f, center = fountainCenter)
    drawCircle(color = Color(0xFFA8DADC), radius = 18f, center = fountainCenter)
    drawCircle(color = Color.White, radius = 6f, center = fountainCenter)

    // Rose Bushes
    val roseColors = listOf(Color(0xFFE63946), Color(0xFFFF758F))
    drawCircle(color = roseColors[0], radius = 10f, center = Offset(gardenBounds.left + 40f, gardenBounds.top + 40f))
    drawCircle(color = roseColors[1], radius = 12f, center = Offset(gardenBounds.right - 40f, gardenBounds.top + 40f))
    drawCircle(color = roseColors[0], radius = 11f, center = Offset(gardenBounds.left + 50f, gardenBounds.bottom - 40f))
    drawCircle(color = roseColors[1], radius = 10f, center = Offset(gardenBounds.right - 50f, gardenBounds.bottom - 40f))

    // === LIVING ROOM ===
    drawRoundRect(
        color = Color(0xFF2C1810),
        topLeft = Offset(livingBounds.left, livingBounds.top),
        size = Size(livingBounds.width, livingBounds.height),
        cornerRadius = CornerRadius(16f, 16f)
    )
    drawRoundRect(
        color = Color(0xFF6F4E37),
        topLeft = Offset(livingBounds.left, livingBounds.top),
        size = Size(livingBounds.width, livingBounds.height),
        cornerRadius = CornerRadius(16f, 16f),
        style = Stroke(width = 3f)
    )

    // Fireplace on north wall of Living Room
    drawRoundRect(
        color = Color(0xFF1B0D05),
        topLeft = Offset(livingBounds.center.x - 36f, livingBounds.top + 4f),
        size = Size(72f, 24f),
        cornerRadius = CornerRadius(6f, 6f)
    )
    drawCircle(
        color = Color(0xFFF97316),
        radius = 8f,
        center = Offset(livingBounds.center.x, livingBounds.top + 16f)
    )

    // Royal Persian Rug
    drawRoundRect(
        color = Color(0x66B91C1C),
        topLeft = Offset(livingBounds.center.x - 50f, livingBounds.center.y - 30f),
        size = Size(100f, 60f),
        cornerRadius = CornerRadius(10f, 10f)
    )

    // === BEDROOM SUITE ===
    drawRoundRect(
        color = Color(0xFF1E1035),
        topLeft = Offset(bedroomBounds.left, bedroomBounds.top),
        size = Size(bedroomBounds.width, bedroomBounds.height),
        cornerRadius = CornerRadius(16f, 16f)
    )
    drawRoundRect(
        color = Color(0xFF6B21A8),
        topLeft = Offset(bedroomBounds.left, bedroomBounds.top),
        size = Size(bedroomBounds.width, bedroomBounds.height),
        cornerRadius = CornerRadius(16f, 16f),
        style = Stroke(width = 3f)
    )

    // Royal Canopy Bed
    drawRoundRect(
        color = Color(0xFF4C1D95),
        topLeft = Offset(bedroomBounds.left + 24f, bedroomBounds.top + 28f),
        size = Size(64f, 80f),
        cornerRadius = CornerRadius(8f, 8f)
    )
    drawRoundRect(
        color = Color(0xFFE2E8F0),
        topLeft = Offset(bedroomBounds.left + 28f, bedroomBounds.top + 32f),
        size = Size(56f, 22f),
        cornerRadius = CornerRadius(6f, 6f)
    )

    // Balcony with starry glow
    drawRoundRect(
        color = Color(0x33FBBF24),
        topLeft = Offset(bedroomBounds.right - 28f, bedroomBounds.center.y - 30f),
        size = Size(24f, 60f),
        cornerRadius = CornerRadius(4f, 4f)
    )

    // Draw Zone Name Labels
    drawIntoCanvas { canvas ->
        val textPaint = Paint().apply {
            color = android.graphics.Color.WHITE
            textSize = 34f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setShadowLayer(6f, 0f, 2f, android.graphics.Color.BLACK)
        }

        val gardenTitle = if (isArabic) "🌸 حديقة القصر والنافورة" else "🌸 Royal Garden"
        val livingTitle = if (isArabic) "🏰 قاعة العرش والمدفأة" else "🏰 Grand Living Room"
        val bedroomTitle = if (isArabic) "👑 جناح النوم الملكي" else "👑 Bedroom Suite"

        canvas.nativeCanvas.drawText(gardenTitle, gardenBounds.left + 24f, gardenBounds.top + 42f, textPaint)
        canvas.nativeCanvas.drawText(livingTitle, livingBounds.left + 20f, livingBounds.top + 44f, textPaint)
        canvas.nativeCanvas.drawText(bedroomTitle, bedroomBounds.left + 20f, bedroomBounds.top + 44f, textPaint)
    }
}

private fun DrawScope.renderCharacter(
    x: Float,
    y: Float,
    direction: String,
    name: String,
    color: Color,
    crownColor: Color,
    emote: String?
) {
    // 1. Soft Shadow
    drawOval(
        color = Color(0x66000000),
        topLeft = Offset(x - 18f, y + 16f),
        size = Size(36f, 12f)
    )

    // 2. Body / Cape
    drawRoundRect(
        color = color,
        topLeft = Offset(x - 14f, y - 6f),
        size = Size(28f, 26f),
        cornerRadius = CornerRadius(8f, 8f)
    )

    // Gold belt
    drawRect(
        color = crownColor,
        topLeft = Offset(x - 14f, y + 6f),
        size = Size(28f, 4f)
    )

    // 3. Head & Skin
    drawCircle(
        color = Color(0xFFFFDBAC),
        radius = 12f,
        center = Offset(x, y - 14f)
    )

    // Crown / Tiara
    drawRoundRect(
        color = crownColor,
        topLeft = Offset(x - 10f, y - 28f),
        size = Size(20f, 6f),
        cornerRadius = CornerRadius(3f, 3f)
    )
    drawCircle(
        color = Color(0xFFF43F5E),
        radius = 3f,
        center = Offset(x, y - 28f)
    )

    // 4. Directional Eyes
    var eyeOffset = 0f
    if (direction == "left") eyeOffset = -3f
    if (direction == "right") eyeOffset = 3f

    drawCircle(
        color = Color.Black,
        radius = 1.8f,
        center = Offset(x - 4f + eyeOffset, y - 14f)
    )
    drawCircle(
        color = Color.Black,
        radius = 1.8f,
        center = Offset(x + 4f + eyeOffset, y - 14f)
    )

    // 5. Name tag badge above avatar
    drawIntoCanvas { canvas ->
        val namePaint = Paint().apply {
            this.color = android.graphics.Color.WHITE
            textSize = 24f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setShadowLayer(4f, 0f, 1f, android.graphics.Color.BLACK)
        }

        val bgPaint = Paint().apply {
            this.color = android.graphics.Color.argb(180, 20, 16, 36)
            isAntiAlias = true
        }

        val textWidth = namePaint.measureText(name)
        val bgRect = android.graphics.RectF(
            x - textWidth / 2 - 12f,
            y - 54f,
            x + textWidth / 2 + 12f,
            y - 30f
        )
        canvas.nativeCanvas.drawRoundRect(bgRect, 8f, 8f, bgPaint)
        canvas.nativeCanvas.drawText(name, x, y - 36f, namePaint)

        // 6. Active Emote Bubble
        if (emote != null) {
            val bubblePaint = Paint().apply {
                this.color = android.graphics.Color.WHITE
                isAntiAlias = true
            }
            val borderPaint = Paint().apply {
                this.color = android.graphics.Color.parseColor("#EC4899")
                style = Paint.Style.STROKE
                strokeWidth = 3f
                isAntiAlias = true
            }
            val emotePaint = Paint().apply {
                textSize = 34f
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }

            canvas.nativeCanvas.drawCircle(x, y - 76f, 20f, bubblePaint)
            canvas.nativeCanvas.drawCircle(x, y - 76f, 20f, borderPaint)
            canvas.nativeCanvas.drawText(emote, x, y - 64f, emotePaint)
        }
    }
}
