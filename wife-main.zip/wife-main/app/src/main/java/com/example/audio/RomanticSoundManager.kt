package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

class RomanticSoundManager(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.Default)
    private val sampleRate = 44100
    var isMuted = false

    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    /**
     * Realistic Romantic Heartbeat sound ("lub-dub" double pulse)
     */
    fun playHeartbeat() {
        if (isMuted) return
        vibrate(longArrayOf(0, 70, 90, 80), intArrayOf(0, 180, 0, 220))

        scope.launch {
            val durationSec = 0.75
            val numSamples = (durationSec * sampleRate).toInt()
            val buffer = ShortArray(numSamples)

            val p1Start = 0
            val p1End = (0.15 * sampleRate).toInt()
            val p2Start = (0.22 * sampleRate).toInt()
            val p2End = (0.42 * sampleRate).toInt()

            // First beat (lub - 55 Hz)
            for (i in p1Start until p1End) {
                val t = (i - p1Start).toDouble() / sampleRate
                val env = exp(-t * 18.0) * sin(t / 0.15 * PI)
                val sample = (sin(2.0 * PI * 55.0 * t) + 0.5 * sin(2.0 * PI * 110.0 * t)) * env * 28000.0
                buffer[i] = sample.toInt().coerceIn(-32768, 32767).toShort()
            }

            // Second beat (dub - 75 Hz)
            for (i in p2Start until p2End) {
                val t = (i - p2Start).toDouble() / sampleRate
                val env = exp(-t * 14.0) * sin(t / 0.20 * PI)
                val sample = (sin(2.0 * PI * 75.0 * t) + 0.4 * sin(2.0 * PI * 150.0 * t)) * env * 32000.0
                buffer[i] = sample.toInt().coerceIn(-32768, 32767).toShort()
            }

            playPcmBuffer(buffer)
        }
    }

    /**
     * Sweet romantic kiss sound (soft upward chirp & pop)
     */
    fun playKissSound() {
        if (isMuted) return
        vibrate(longArrayOf(0, 40), intArrayOf(0, 255))

        scope.launch {
            val durationSec = 0.28
            val numSamples = (durationSec * sampleRate).toInt()
            val buffer = ShortArray(numSamples)

            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                val progress = t / durationSec
                // Upward frequency sweep 1400Hz -> 2600Hz
                val freq = 1400.0 + progress * 1200.0
                val env = exp(-progress * 5.0) * sin(progress * PI)
                val sample = sin(2.0 * PI * freq * t) * env * 24000.0
                buffer[i] = sample.toInt().coerceIn(-32768, 32767).toShort()
            }

            playPcmBuffer(buffer)
        }
    }

    /**
     * Warm embrace / celestial hug chime chord (Rich harmony)
     */
    fun playWarmHugSound() {
        if (isMuted) return
        vibrate(longArrayOf(0, 120), intArrayOf(0, 150))

        scope.launch {
            val durationSec = 1.2
            val numSamples = (durationSec * sampleRate).toInt()
            val buffer = ShortArray(numSamples)

            // C5 (523Hz), E5 (659Hz), G5 (784Hz), C6 (1046Hz)
            val freqs = doubleArrayOf(523.25, 659.25, 783.99, 1046.50)

            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                var sum = 0.0
                for (f in freqs) {
                    val env = exp(-t * 2.8)
                    sum += sin(2.0 * PI * f * t) * env
                }
                val sample = (sum / freqs.size) * 26000.0
                buffer[i] = sample.toInt().coerceIn(-32768, 32767).toShort()
            }

            playPcmBuffer(buffer)
        }
    }

    /**
     * Dreamy royal waltz arpeggio melody (Harp / music box notes)
     */
    fun playRomanticWaltz() {
        if (isMuted) return
        vibrate(longArrayOf(0, 50, 100, 50), intArrayOf(0, 120, 0, 180))

        scope.launch {
            val notes = doubleArrayOf(587.33, 739.99, 880.00, 1174.66, 1479.98) // D5, F#5, A5, D6, F#6
            val noteDuration = 0.22
            val totalDuration = notes.size * noteDuration + 0.4
            val numSamples = (totalDuration * sampleRate).toInt()
            val buffer = ShortArray(numSamples)

            for (noteIdx in notes.indices) {
                val freq = notes[noteIdx]
                val startSample = (noteIdx * noteDuration * sampleRate).toInt()
                val noteSamples = (0.5 * sampleRate).toInt()

                for (i in 0 until noteSamples) {
                    val globalIdx = startSample + i
                    if (globalIdx >= numSamples) break
                    val t = i.toDouble() / sampleRate
                    val env = exp(-t * 4.5)
                    val sample = sin(2.0 * PI * freq * t) * env * 18000.0
                    val currentVal = buffer[globalIdx].toInt()
                    buffer[globalIdx] = (currentVal + sample.toInt()).coerceIn(-32768, 32767).toShort()
                }
            }

            playPcmBuffer(buffer)
        }
    }

    /**
     * Proximity approach chime when partners are within 50px
     */
    fun playProximityChime() {
        if (isMuted) return
        vibrate(longArrayOf(0, 35), intArrayOf(0, 100))

        scope.launch {
            val durationSec = 0.45
            val numSamples = (durationSec * sampleRate).toInt()
            val buffer = ShortArray(numSamples)

            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                val freq = if (t < 0.20) 880.0 else 1318.51 // A5 -> E6
                val env = exp(-t * 4.0)
                val sample = sin(2.0 * PI * freq * t) * env * 22000.0
                buffer[i] = sample.toInt().coerceIn(-32768, 32767).toShort()
            }

            playPcmBuffer(buffer)
        }
    }

    private fun playPcmBuffer(buffer: ShortArray) {
        try {
            val minBufSize = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBufSize, buffer.size * 2))
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            audioTrack.write(buffer, 0, buffer.size)
            audioTrack.play()

            // Release track after playback completes
            Thread.sleep((buffer.size * 1000L / sampleRate) + 100)
            audioTrack.stop()
            audioTrack.release()
        } catch (e: Exception) {
            // Audio play completed or interrupted
        }
    }

    private fun vibrate(timings: LongArray, amplitudes: IntArray) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(timings[1])
            }
        } catch (_: Exception) {}
    }
}
