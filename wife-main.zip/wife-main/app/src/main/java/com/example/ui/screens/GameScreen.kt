package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.RomanticSoundManager
import com.example.game.PalaceGameEngine
import com.example.model.InteractionPayload
import com.example.network.LocalP2PManager
import com.example.ui.components.GameCanvas
import com.example.ui.components.VirtualJoystick
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

data class ActionItem(
    val id: String,
    val title: String,
    val titleAr: String,
    val icon: String,
    val desc: String,
    val descAr: String,
    val color: Color
)

@Composable
fun GameScreen(
    p2pManager: LocalP2PManager,
    localPlayerName: String,
    isArabicDefault: Boolean = true,
    onExitGame: () -> Unit
) {
    val context = LocalContext.current
    val soundManager = remember { RomanticSoundManager(context) }
    var isArabic by remember { mutableStateOf(isArabicDefault) }
    var isMuted by remember { mutableStateOf(false) }

    val engine = remember { PalaceGameEngine() }
    val partnerName by p2pManager.partnerName.collectAsState()
    val latencyMs by p2pManager.latencyMs.collectAsState()

    var joystickDx by remember { mutableFloatStateOf(0f) }
    var joystickDy by remember { mutableFloatStateOf(0f) }

    var showInteractionDialog by remember { mutableStateOf(false) }
    var incomingAction by remember { mutableStateOf<InteractionPayload?>(null) }
    var activeCelebration by remember { mutableStateOf<String?>(null) }
    var celebrationTimer by remember { mutableIntStateOf(0) }

    var syncTimer by remember { mutableFloatStateOf(0f) }
    var wasInProximity by remember { mutableStateOf(false) }

    var screenWidth by remember { mutableFloatStateOf(1080f) }
    var screenHeight by remember { mutableFloatStateOf(1920f) }

    // Update mute state in sound manager
    LaunchedEffect(isMuted) {
        soundManager.isMuted = isMuted
    }

    // 1. Game Loop (60 FPS)
    LaunchedEffect(Unit) {
        var lastTime = System.currentTimeMillis()
        while (isActive) {
            val now = System.currentTimeMillis()
            val dt = ((now - lastTime) / 1000f).coerceIn(0.001f, 0.05f)
            lastTime = now

            // Update player movement & physics
            engine.updateJoystick(joystickDx, joystickDy, dt, screenWidth, screenHeight)
            engine.updatePhysics(dt, screenWidth, screenHeight)

            // Proximity Sound Trigger when entering proximity radius
            if (engine.isWithinProximity && !wasInProximity) {
                soundManager.playProximityChime()
            }
            wasInProximity = engine.isWithinProximity

            // Stream position every 50ms
            syncTimer += dt
            if (syncTimer >= 0.050f) {
                syncTimer = 0f
                p2pManager.sendMovement(engine.localX, engine.localY, engine.localDir)
            }

            delay(16) // ~60fps
        }
    }

    // 2. Listen to incoming movement from remote player
    LaunchedEffect(Unit) {
        p2pManager.movementFlow.collect { move ->
            engine.updateRemoteTarget(move.x, move.y, move.dir)
        }
    }

    // 3. Listen to incoming interaction actions
    LaunchedEffect(Unit) {
        p2pManager.interactionFlow.collect { action ->
            if (action.status == "REQUEST") {
                incomingAction = action
                soundManager.playHeartbeat()
            } else if (action.status == "ACCEPT") {
                activeCelebration = action.actionId
                celebrationTimer = action.timerSeconds ?: 0

                val emote = when (action.actionId) {
                    "HUG" -> {
                        soundManager.playWarmHugSound()
                        "🤗"
                    }
                    "KISS" -> {
                        soundManager.playKissSound()
                        "💋"
                    }
                    "DANCE" -> {
                        soundManager.playRomanticWaltz()
                        "💃"
                    }
                    "STROLL" -> {
                        soundManager.playRomanticWaltz()
                        "🌸"
                    }
                    else -> "💖"
                }
                engine.triggerEmote(emote, isLocal = true)
                engine.triggerEmote(emote, isLocal = false)
            }
        }
    }

    // 4. Active celebration countdown timer
    LaunchedEffect(celebrationTimer) {
        if (celebrationTimer > 0) {
            while (celebrationTimer > 0) {
                delay(1000)
                celebrationTimer--
            }
            activeCelebration = null
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize().background(Color(0xFF0F0B18))) {
        screenWidth = constraints.maxWidth.toFloat()
        screenHeight = constraints.maxHeight.toFloat()

        // 1. Game Canvas
        GameCanvas(
            engine = engine,
            localPlayerName = localPlayerName,
            remotePlayerName = partnerName,
            isArabic = isArabic,
            modifier = Modifier.fillMaxSize()
        )

        // 2. Top Game HUD
        SafeAreaTopHud(
            zoneName = if (isArabic) engine.currentZone.displayNameAr else engine.currentZone.displayName,
            latencyMs = latencyMs,
            isArabic = isArabic,
            isMuted = isMuted,
            onToggleSound = { isMuted = !isMuted },
            onHeartbeat = { soundManager.playHeartbeat() },
            onToggleLanguage = { isArabic = !isArabic },
            onExit = {
                p2pManager.disconnect()
                onExitGame()
            }
        )

        // 3. Proximity Action Prompt Button (Pulsing when R <= 50px)
        AnimatedVisibility(
            visible = engine.isWithinProximity,
            enter = scaleIn() + fadeIn(),
            exit = scaleOut() + fadeOut(),
            modifier = Modifier
                .align(if (isArabic) Alignment.BottomStart else Alignment.BottomEnd)
                .padding(
                    bottom = 140.dp,
                    start = if (isArabic) 24.dp else 0.dp,
                    end = if (!isArabic) 24.dp else 0.dp
                )
        ) {
            Button(
                onClick = {
                    soundManager.playHeartbeat()
                    showInteractionDialog = true
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48)),
                shape = RoundedCornerShape(22.dp),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp),
                modifier = Modifier.testTag("interact_button")
            ) {
                Icon(Icons.Default.Favorite, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isArabic) "لحظة رومانسية 💕" else "Interact 💕",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color.White
                )
            }
        }

        // 4. Virtual Joystick
        Box(
            modifier = Modifier
                .align(if (isArabic) Alignment.BottomEnd else Alignment.BottomStart)
                .padding(
                    bottom = 32.dp,
                    end = if (isArabic) 32.dp else 0.dp,
                    start = if (!isArabic) 32.dp else 0.dp
                )
                .testTag("virtual_joystick")
        ) {
            VirtualJoystick(
                onDirectionChange = { dx, dy ->
                    joystickDx = dx
                    joystickDy = dy
                }
            )
        }

        // 5. Active Synchronized Timer / Celebration Banner
        if (activeCelebration != null) {
            CelebrationBanner(
                actionId = activeCelebration!!,
                remainingSec = celebrationTimer,
                isArabic = isArabic,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 84.dp)
            )
        }

        // 6. Interaction Selection Modal Dialog
        if (showInteractionDialog) {
            InteractionSelectionDialog(
                zoneName = if (isArabic) engine.currentZone.displayNameAr else engine.currentZone.displayName,
                isArabic = isArabic,
                onDismiss = { showInteractionDialog = false },
                onSelectAction = { actionId, timerSec ->
                    showInteractionDialog = false
                    p2pManager.sendInteraction(
                        actionId = actionId,
                        zone = if (isArabic) engine.currentZone.displayNameAr else engine.currentZone.displayName,
                        status = "REQUEST",
                        timerSeconds = timerSec
                    )
                    // Immediate audio & visual feedback
                    activeCelebration = actionId
                    celebrationTimer = timerSec ?: 0

                    val emote = when (actionId) {
                        "HUG" -> {
                            soundManager.playWarmHugSound()
                            "🤗"
                        }
                        "KISS" -> {
                            soundManager.playKissSound()
                            "💋"
                        }
                        "DANCE" -> {
                            soundManager.playRomanticWaltz()
                            "💃"
                        }
                        else -> {
                            soundManager.playRomanticWaltz()
                            "🌸"
                        }
                    }
                    engine.triggerEmote(emote, isLocal = true)
                }
            )
        }

        // 7. Incoming Interaction Request Alert
        incomingAction?.let { action ->
            IncomingActionDialog(
                requesterName = partnerName,
                action = action,
                isArabic = isArabic,
                onAccept = {
                    p2pManager.sendInteraction(
                        actionId = action.actionId,
                        zone = action.zone,
                        status = "ACCEPT",
                        timerSeconds = action.timerSeconds
                    )
                    activeCelebration = action.actionId
                    celebrationTimer = action.timerSeconds ?: 0

                    val emote = when (action.actionId) {
                        "HUG" -> {
                            soundManager.playWarmHugSound()
                            "🤗"
                        }
                        "KISS" -> {
                            soundManager.playKissSound()
                            "💋"
                        }
                        "DANCE" -> {
                            soundManager.playRomanticWaltz()
                            "💃"
                        }
                        else -> {
                            soundManager.playRomanticWaltz()
                            "🌸"
                        }
                    }
                    engine.triggerEmote(emote, isLocal = true)
                    engine.triggerEmote(emote, isLocal = false)
                    incomingAction = null
                },
                onDecline = {
                    p2pManager.sendInteraction(
                        actionId = action.actionId,
                        zone = action.zone,
                        status = "DECLINE"
                    )
                    incomingAction = null
                }
            )
        }
    }
}

@Composable
private fun SafeAreaTopHud(
    zoneName: String,
    latencyMs: Int,
    isArabic: Boolean,
    isMuted: Boolean,
    onToggleSound: () -> Unit,
    onHeartbeat: () -> Unit,
    onToggleLanguage: () -> Unit,
    onExit: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 22.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Zone Badge
        Surface(
            color = Color(0xCC1A132F),
            shape = RoundedCornerShape(20.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Place, contentDescription = null, tint = Color(0xFFFBBF24), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = zoneName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Heartbeat Sound Button
        IconButton(
            onClick = onHeartbeat,
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(0x99BE123C))
                .testTag("heartbeat_button")
        ) {
            Icon(Icons.Default.Favorite, contentDescription = "Heartbeat", tint = Color(0xFFFDE047), modifier = Modifier.size(18.dp))
        }

        Spacer(modifier = Modifier.width(6.dp))

        // Sound Toggle Button
        IconButton(
            onClick = onToggleSound,
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(0x66000000))
                .testTag("sound_toggle_button")
        ) {
            Icon(
                if (isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                contentDescription = "Sound",
                tint = if (isMuted) Color.Gray else Color(0xFF38BDF8),
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(6.dp))

        // Language Toggle Button
        Surface(
            onClick = onToggleLanguage,
            color = Color(0x66000000),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(
                text = if (isArabic) "عربي" else "EN",
                color = Color(0xFFE2E8F0),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
            )
        }

        Spacer(modifier = Modifier.width(6.dp))

        // Latency Badge
        Surface(
            color = Color(0x99000000),
            shape = RoundedCornerShape(14.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(Color(0xFF10B981)))
                Spacer(modifier = Modifier.width(5.dp))
                Text(text = "$latencyMs ms", color = Color(0xFFD1D5DB), fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.width(6.dp))

        // Exit Button
        IconButton(
            onClick = onExit,
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(0x66000000))
                .testTag("exit_game_button")
        ) {
            Icon(Icons.Default.Close, contentDescription = "Exit", tint = Color.White, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun CelebrationBanner(
    actionId: String,
    remainingSec: Int,
    isArabic: Boolean,
    modifier: Modifier = Modifier
) {
    val actionName = when (actionId) {
        "HUG" -> if (isArabic) "عناق دافئ" else "Warm Embrace"
        "KISS" -> if (isArabic) "قبلة حب رقيقة" else "Sweet Kiss"
        "DANCE" -> if (isArabic) "رقصة رومانسية" else "Royal Waltz"
        "STROLL" -> if (isArabic) "نزهة قمرية" else "Moonlit Stroll"
        else -> actionId
    }

    Surface(
        color = Color(0xEE831843),
        shape = RoundedCornerShape(20.dp),
        shadowElevation = 8.dp,
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "✨", fontSize = 18.sp)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isArabic) "لحظة $actionName مشتركة نشطة 💕" else "Synchronized $actionName Active 💕",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            if (remainingSec > 0) {
                Spacer(modifier = Modifier.width(10.dp))
                Surface(
                    color = Color(0x66000000),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = "$remainingSec ${if (isArabic) "ث" else "s"}",
                        color = Color(0xFFFDE047),
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun InteractionSelectionDialog(
    zoneName: String,
    isArabic: Boolean,
    onDismiss: () -> Unit,
    onSelectAction: (actionId: String, timerSeconds: Int?) -> Unit
) {
    var selectedAction by remember { mutableStateOf<String?>("HUG") }
    var selectedTimer by remember { mutableIntStateOf(30) }
    var includeTimer by remember { mutableStateOf(true) }

    val actionList = remember {
        listOf(
            ActionItem("HUG", "Warm Embrace", "عناق دافئ", "🤗", "Hold each other close", "احتضان الشريك بحنان ودفء", Color(0xFFF43F5E)),
            ActionItem("KISS", "Sweet Kiss", "قبلة رقيقة", "💋", "Tender romantic moment", "لحظة حب رومانسية ساحرة", Color(0xFFE11D48)),
            ActionItem("DANCE", "Royal Waltz", "رقصة رومانسية", "💃", "Slow dance together", "رقصة هادئة على ألحان الحب", Color(0xFF8B5CF6)),
            ActionItem("STROLL", "Moonlit Stroll", "نزهة قمرية", "🌸", "Walk around fountain", "سير مشترك حول نافورة الورد", Color(0xFF10B981))
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1B162B),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "✨", fontSize = 22.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        if (isArabic) "لحظات الحب والرومانسية" else "Proximity Interaction",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    Text(
                        if (isArabic) "في $zoneName" else "Active in $zoneName",
                        color = Color(0xFFF472B6),
                        fontSize = 12.sp
                    )
                }
            }
        },
        text = {
            Column {
                actionList.chunked(2).forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        row.forEach { item ->
                            val isSelected = selectedAction == item.id
                            Surface(
                                onClick = { selectedAction = item.id },
                                color = if (isSelected) item.color.copy(alpha = 0.35f) else Color(0xFF261F3D),
                                shape = RoundedCornerShape(14.dp),
                                border = if (isSelected) ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(item.color, Color.White))) else null,
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(vertical = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(item.icon, fontSize = 24.sp)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = if (isArabic) item.titleAr else item.title,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = if (isArabic) item.descAr else item.desc,
                                        color = Color.White.copy(alpha = 0.6f),
                                        fontSize = 10.sp,
                                        lineHeight = 12.sp
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Timer Option
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Checkbox(
                        checked = includeTimer,
                        onCheckedChange = { includeTimer = it },
                        colors = CheckboxDefaults.colors(checkedColor = Color(0xFFEC4899))
                    )
                    Text(
                        text = if (isArabic) "مؤقت رومانسي: " else "Timer: ",
                        color = Color.White,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(15, 30, 60).forEach { sec ->
                            FilterChip(
                                selected = selectedTimer == sec && includeTimer,
                                onClick = {
                                    includeTimer = true
                                    selectedTimer = sec
                                },
                                label = { Text("${sec}${if (isArabic) "ث" else "s"}", fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    selectedAction?.let {
                        onSelectAction(it, if (includeTimer) selectedTimer else null)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48)),
                modifier = Modifier.testTag("send_interaction_button")
            ) {
                Text(if (isArabic) "إرسال الطلب للحبيب 💕" else "Send Request 💕", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (isArabic) "إلغاء" else "Cancel", color = Color.White.copy(alpha = 0.6f))
            }
        }
    )
}

@Composable
private fun IncomingActionDialog(
    requesterName: String,
    action: InteractionPayload,
    isArabic: Boolean,
    onAccept: () -> Unit,
    onDecline: () -> Unit
) {
    val emoji = when (action.actionId) {
        "HUG" -> "🤗"
        "KISS" -> "💋"
        "DANCE" -> "💃"
        else -> "🌸"
    }

    val actionLabel = when (action.actionId) {
        "HUG" -> if (isArabic) "عناق دافئ" else "Warm Embrace"
        "KISS" -> if (isArabic) "قبلة حب رقيقة" else "Sweet Kiss"
        "DANCE" -> if (isArabic) "رقصة رومانسية" else "Royal Waltz"
        else -> if (isArabic) "نزهة قمرية" else "Moonlit Stroll"
    }

    AlertDialog(
        onDismissRequest = onDecline,
        containerColor = Color(0xFF241538),
        title = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = emoji, fontSize = 48.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (isArabic) "$requesterName يدعوك بلطف!" else "$requesterName invites you!",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    textAlign = TextAlign.Center
                )
            }
        },
        text = {
            Text(
                text = if (isArabic) {
                    "هل تود مشاركة $actionLabel في ${action.zone} مع شريكك؟ 💕"
                } else {
                    "Would you like to share a $actionLabel together in the ${action.zone}?"
                },
                color = Color.White.copy(alpha = 0.85f),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = onAccept,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48)),
                modifier = Modifier.testTag("accept_interaction_button")
            ) {
                Text(if (isArabic) "قبول بحب 💕" else "Accept 💕", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDecline) {
                Text(if (isArabic) "لاحقاً" else "Decline", color = Color.White.copy(alpha = 0.6f))
            }
        }
    )
}
