package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PushGuideScreen(
    onBack: () -> Unit
) {
    Scaffold(
        containerColor = Color(0xFF0C0A14),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "دليل الرفع والبناء الآلي لنظام أندرويد 15",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF161226))
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            // Repository & Secrets Status Card
            Surface(
                color = Color(0xFF1E1833),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🔐", fontSize = 24.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            "مستودع GitHub ومتغيرات الأمان المكتشفة",
                            color = Color(0xFFF472B6),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "تم ربط وتجهيز ملف البناء الآلي GitHub Actions مع مستودعك الخاص:\n" +
                                "👉 https://github.com/aboanasanam42-cpu/wife.git\n\n" +
                                "تم تكوين سكريبت البناء (.github/workflows/build_apk.yml) لفك تشفير وتطبيق المتغيرات السرية المضافة في المستودع تلقائياً:\n" +
                                "• KEYSTORE_BASE64 (مفتاح التوقيع الرقمي)\n" +
                                "• CM_KEYSTORE_PASSWORD & CM_KEY_PASSWORD\n" +
                                "• CM_KEY_ALIAS\n" +
                                "• GEMINI_API_KEY",
                        color = Color(0xFFE2E8F0),
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Bash Command Card
            Surface(
                color = Color(0xFF0F172A),
                shape = RoundedCornerShape(14.dp),
                border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF334155))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Terminal, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("خطوة الرفع التلقائي (Terminal):", color = Color(0xFF94A3B8), fontSize = 12.sp)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "chmod +x setup_and_push.sh\n./setup_and_push.sh",
                        color = Color(0xFF38BDF8),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "(يقوم السكريبت تلقائياً بالرفع المباشر إلى مستودع aboanasanam42-cpu/wife)",
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                "مميزات اللعبة المضافة في هذا التحديث:",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            val features = listOf(
                "أصوات الحب والرومانسية 🎵" to "توليد نغمات صوتية حية (نبضات القلب الطبيعية، صوت القبلة، رنين العناق الدافئ، ألحان الرقصة الرومانسية).",
                "تعريب كامل للواجهات 🇸🇦" to "واجهات باللغة العربية، أسماء المناطق بالقصر، حوارات التفاعل الرومانسي ومؤقت الحب.",
                "بناء APK موقع لأندرويد 15 📦" to "تصدير حزمة APK جاهزة للتثبيت المباشر على هاتفك وهاتف الشريك المتوافقين مع SDK 35.",
                "شبكة P2P أوفلاين بدون إنترنت 📡" to "اتصال مباشر بين الهاتفين عبر الواي فاي المحلي أو نقطة الاتصال مع زمن استجابة فائق السرعة (50ms)."
            )

            features.forEach { (title, desc) ->
                Surface(
                    color = Color(0xFF171324),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(modifier = Modifier.padding(12.dp)) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(title, color = Color(0xFFF472B6), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(desc, color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp, lineHeight = 16.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = onBack,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("back_to_lobby_button"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("العودة إلى قاعة القصر", fontWeight = FontWeight.Bold)
            }
        }
    }
}
