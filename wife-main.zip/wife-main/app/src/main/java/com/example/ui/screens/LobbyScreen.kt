package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.RomanticSoundManager
import com.example.network.LocalP2PManager
import com.example.network.PeerState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LobbyScreen(
    p2pManager: LocalP2PManager,
    isArabicDefault: Boolean = true,
    onStartGame: (playerName: String) -> Unit,
    onOpenPushGuide: () -> Unit
) {
    var isArabic by remember { mutableStateOf(isArabicDefault) }
    var playerName by remember { mutableStateOf(if (isArabic) "أمير القصر" else "Prince Charming") }
    var hostIpInput by remember { mutableStateOf("192.168.43.1") }

    val context = LocalContext.current
    val soundManager = remember { RomanticSoundManager(context) }

    val peerState by p2pManager.connectionState.collectAsState()
    val localIp = remember { p2pManager.getLocalIpAddress() }

    val isConnected = peerState == PeerState.CONNECTED

    LaunchedEffect(isConnected) {
        if (isConnected) {
            soundManager.playRomanticWaltz()
            onStartGame(playerName)
        }
    }

    Scaffold(
        containerColor = Color(0xFF0C0A14)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Language & Sound Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Heartbeat Sound Test Button
                IconButton(
                    onClick = { soundManager.playHeartbeat() },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0x66BE123C))
                ) {
                    Icon(Icons.Default.Favorite, contentDescription = "Heartbeat", tint = Color(0xFFF43F5E), modifier = Modifier.size(20.dp))
                }

                // Language Toggle
                Surface(
                    onClick = {
                        isArabic = !isArabic
                        if (isArabic && playerName == "Prince Charming") playerName = "أمير القصر"
                        if (!isArabic && playerName == "أمير القصر") playerName = "Prince Charming"
                    },
                    color = Color(0xFF1E192E),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Language, contentDescription = null, tint = Color(0xFFEC4899), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isArabic) "اللغة: العربية" else "Language: EN",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Palace Emblem Header
            Box(
                modifier = Modifier
                    .size(86.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF7C3AED), Color(0xFFEC4899))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "🏰", fontSize = 46.sp)
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = if (isArabic) "قصر الحب والرومانسية" else "Palace P2P",
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                letterSpacing = 1.sp,
                textAlign = TextAlign.Center
            )

            Text(
                text = if (isArabic) "لعبة ثنائية تفاعلية أوفلاين للأزواج والأحباب بدون إنترنت" else "2D Local Multiplayer for Couples & Friends (Offline P2P)",
                fontSize = 13.sp,
                color = Color(0xFFE2E8F0).copy(alpha = 0.75f),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Player Name Input
            OutlinedTextField(
                value = playerName,
                onValueChange = { playerName = it },
                label = { Text(if (isArabic) "اسم شخصيتك (مثال: أمير القصر / حبيبي)" else "Your Character Name") },
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = "Name", tint = Color(0xFFEC4899)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("player_name_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFFEC4899),
                    unfocusedBorderColor = Color(0x33FFFFFF),
                    focusedLabelColor = Color(0xFFEC4899),
                    unfocusedLabelColor = Color.White.copy(alpha = 0.7f),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(16.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(14.dp))

            // IP Address Badge
            Surface(
                color = Color(0xFF1E192E),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Wifi, contentDescription = "WiFi", tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isArabic) "عنوان IP المحلي لجهازك: $localIp" else "Device Local IP: $localIp",
                        color = Color(0xFFBAE6FD),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Action 1: Host Room (Phone A)
            Button(
                onClick = {
                    soundManager.playWarmHugSound()
                    p2pManager.startHosting("Royal Room")
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("host_room_button"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                shape = RoundedCornerShape(14.dp),
                enabled = peerState != PeerState.HOSTING
            ) {
                Icon(Icons.Default.CellTower, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                val hostText = if (isArabic) {
                    if (peerState == PeerState.HOSTING) "جارٍ بث الغرفة وانتظار الشريك..." else "إنشاء غرفة القصر (الهاتف أ - المضيف)"
                } else {
                    if (peerState == PeerState.HOSTING) "Broadcasting Room (Phone A)..." else "Host Room (Phone A)"
                }
                Text(hostText, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action 2: Join Partner (Phone B)
            Surface(
                color = Color(0xFF191528),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isArabic) "الانضمام إلى الشريك (الهاتف ب)" else "Join Partner (Phone B)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = hostIpInput,
                        onValueChange = { hostIpInput = it },
                        label = { Text(if (isArabic) "عنوان IP الخاص بالهاتف أ" else "Host IP (e.g., $localIp)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFEC4899),
                            unfocusedBorderColor = Color(0x33FFFFFF),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            soundManager.playKissSound()
                            p2pManager.connectToHost(hostIpInput)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("join_room_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDB2777)),
                        shape = RoundedCornerShape(12.dp),
                        enabled = peerState != PeerState.CONNECTING
                    ) {
                        Icon(Icons.Default.Search, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        val joinText = if (isArabic) {
                            if (peerState == PeerState.CONNECTING) "جارٍ الاتصال بهاتف الشريك..." else "اتصال بالهاتف أ والبدء 💕"
                        } else {
                            if (peerState == PeerState.CONNECTING) "Connecting to Host..." else "Connect to Host IP"
                        }
                        Text(joinText, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action 3: Solo / Companion Practice Mode
            OutlinedButton(
                onClick = {
                    soundManager.playWarmHugSound()
                    p2pManager.startSoloCompanionMode()
                    onStartGame(playerName)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("solo_mode_button"),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFF472B6)),
                border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(Color(0xFF8B5CF6), Color(0xFFEC4899)))),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(
                    text = if (isArabic) "💖 وضع اللعب والتجربة مع رفيق افتراضي" else "💖 Solo / Companion Practice Mode",
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // GitHub & APK Setup Automation Guide Button
            TextButton(
                onClick = onOpenPushGuide,
                modifier = Modifier.testTag("github_guide_button")
            ) {
                Icon(Icons.Default.Code, contentDescription = null, tint = Color(0xFFA78BFA), modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isArabic) "دليل رفع المشروع إلى مستودع GitHub الخاص بك (Android 15)" else "Setup & GitHub Push Guide (Android 15)",
                    color = Color(0xFFA78BFA),
                    fontSize = 13.sp
                )
            }
        }
    }
}
