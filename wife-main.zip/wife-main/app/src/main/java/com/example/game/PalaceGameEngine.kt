package com.example.game

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import kotlin.math.sqrt

enum class PalaceZone(
    val displayName: String,
    val displayNameAr: String,
    val color: Color,
    val accent: Color
) {
    GARDEN("Royal Garden", "حديقة القصر والنافورة", Color(0xFF1B4332), Color(0xFF40916C)),
    LIVING_ROOM("Grand Living Room", "قاعة العرش والمدفأة", Color(0xFF3D2619), Color(0xFFB08968)),
    BEDROOM("Royal Bedroom Suite", "جناح النوم الملكي", Color(0xFF241442), Color(0xFF7C3AED))
}

object ZoneDefinitions {
    fun getGardenBounds(w: Float, h: Float): Rect {
        return Rect(16f, 16f, w - 16f, h * 0.42f)
    }

    fun getLivingRoomBounds(w: Float, h: Float): Rect {
        val top = h * 0.45f
        return Rect(16f, top, w * 0.48f, h - 16f)
    }

    fun getBedroomBounds(w: Float, h: Float): Rect {
        val top = h * 0.45f
        return Rect(w * 0.52f, top, w - 16f, h - 16f)
    }
}

data class HeartParticle(
    var x: Float,
    var y: Float,
    var vy: Float,
    var vx: Float,
    var size: Float,
    var alpha: Float,
    var life: Float = 1.0f
)

class PalaceGameEngine {

    companion object {
        const val PROXIMITY_RADIUS = 50f
    }

    var localX = 120f
    var localY = 140f
    var localDir = "idle"

    var remoteX = 220f
    var remoteY = 140f
    var remoteTargetX = 220f
    var remoteTargetY = 140f
    var remoteDir = "idle"

    var currentZone = PalaceZone.GARDEN
    var distanceBetween = 999f
    var isWithinProximity = false

    var localEmote: String? = null
    var localEmoteTimer: Float = 0f

    var remoteEmote: String? = null
    var remoteEmoteTimer: Float = 0f

    val particles = mutableListOf<HeartParticle>()

    fun updateJoystick(dx: Float, dy: Float, dt: Float, mapW: Float, mapH: Float) {
        val speed = 150f
        if (dx != 0f || dy != 0f) {
            localX += dx * speed * dt
            localY += dy * speed * dt

            localDir = if (kotlin.math.abs(dx) > kotlin.math.abs(dy)) {
                if (dx > 0) "right" else "left"
            } else {
                if (dy > 0) "down" else "up"
            }
        } else {
            localDir = "idle"
        }

        // Clamp to map
        localX = localX.coerceIn(30f, (mapW - 30f).coerceAtLeast(30f))
        localY = localY.coerceIn(30f, (mapH - 30f).coerceAtLeast(30f))
    }

    fun updateRemoteTarget(targetX: Float, targetY: Float, dir: String) {
        remoteTargetX = targetX
        remoteTargetY = targetY
        remoteDir = dir
    }

    fun updatePhysics(dt: Float, mapW: Float, mapH: Float) {
        // Interpolate remote position
        remoteX += (remoteTargetX - remoteX) * (12f * dt).coerceIn(0f, 1f)
        remoteY += (remoteTargetY - remoteY) * (12f * dt).coerceIn(0f, 1f)

        // Euclidean distance calculation: R = sqrt((x1-x2)^2 + (y1-y2)^2)
        val ddx = localX - remoteX
        val ddy = localY - remoteY
        distanceBetween = sqrt(ddx * ddx + ddy * ddy)
        isWithinProximity = distanceBetween <= PROXIMITY_RADIUS

        // Check active zone
        val garden = ZoneDefinitions.getGardenBounds(mapW, mapH)
        val living = ZoneDefinitions.getLivingRoomBounds(mapW, mapH)
        val bedroom = ZoneDefinitions.getBedroomBounds(mapW, mapH)

        val localPoint = Offset(localX, localY)
        currentZone = when {
            garden.contains(localPoint) -> PalaceZone.GARDEN
            living.contains(localPoint) -> PalaceZone.LIVING_ROOM
            bedroom.contains(localPoint) -> PalaceZone.BEDROOM
            else -> PalaceZone.GARDEN
        }

        // Update emotes
        if (localEmoteTimer > 0f) {
            localEmoteTimer -= dt
            if (localEmoteTimer <= 0f) localEmote = null
        }
        if (remoteEmoteTimer > 0f) {
            remoteEmoteTimer -= dt
            if (remoteEmoteTimer <= 0f) remoteEmote = null
        }

        // Update particles
        val iterator = particles.iterator()
        while (iterator.hasNext()) {
            val p = iterator.next()
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.life -= dt * 0.8f
            p.alpha = p.life.coerceIn(0f, 1f)
            if (p.life <= 0f) {
                iterator.remove()
            }
        }
    }

    fun triggerEmote(emote: String, isLocal: Boolean) {
        if (isLocal) {
            localEmote = emote
            localEmoteTimer = 3.5f
        } else {
            remoteEmote = emote
            remoteEmoteTimer = 3.5f
        }

        // Spawn heart particles around players
        val originX = (localX + remoteX) / 2f
        val originY = (localY + remoteY) / 2f
        for (i in 0 until 12) {
            particles.add(
                HeartParticle(
                    x = originX + (-20f + kotlin.random.Random.nextFloat() * 40f),
                    y = originY + (-20f + kotlin.random.Random.nextFloat() * 40f),
                    vy = -30f - kotlin.random.Random.nextFloat() * 60f,
                    vx = -20f + kotlin.random.Random.nextFloat() * 40f,
                    size = 14f + kotlin.random.Random.nextFloat() * 12f,
                    alpha = 1f
                )
            )
        }
    }
}
