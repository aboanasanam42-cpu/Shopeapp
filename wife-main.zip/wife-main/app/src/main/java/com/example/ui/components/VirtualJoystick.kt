package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlin.math.sqrt

@Composable
fun VirtualJoystick(
    modifier: Modifier = Modifier,
    radius: Float = 140f,
    onDirectionChange: (dx: Float, dy: Float) -> Unit
) {
    var knobOffset by remember { mutableStateOf(Offset.Zero) }

    Box(
        modifier = modifier
            .size((radius * 2 / 2.7f).dp)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset ->
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val delta = offset - center
                        val dist = sqrt(delta.x * delta.x + delta.y * delta.y)
                        val clamped = if (dist > radius) {
                            Offset(delta.x / dist * radius, delta.y / dist * radius)
                        } else {
                            delta
                        }
                        knobOffset = clamped
                        onDirectionChange(clamped.x / radius, clamped.y / radius)
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val newOffset = knobOffset + dragAmount
                        val dist = sqrt(newOffset.x * newOffset.x + newOffset.y * newOffset.y)
                        val clamped = if (dist > radius) {
                            Offset(newOffset.x / dist * radius, newOffset.y / dist * radius)
                        } else {
                            newOffset
                        }
                        knobOffset = clamped
                        onDirectionChange(clamped.x / radius, clamped.y / radius)
                    },
                    onDragEnd = {
                        knobOffset = Offset.Zero
                        onDirectionChange(0f, 0f)
                    },
                    onDragCancel = {
                        knobOffset = Offset.Zero
                        onDirectionChange(0f, 0f)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.matchParentSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)

            // Outer Base Ring
            drawCircle(
                color = Color(0x661A132F),
                radius = radius,
                center = center
            )
            drawCircle(
                color = Color(0x66EC4899),
                radius = radius,
                center = center,
                style = Stroke(width = 3f)
            )

            // Inner Guide Cross
            drawLine(
                color = Color(0x33FFFFFF),
                start = Offset(center.x - radius * 0.5f, center.y),
                end = Offset(center.x + radius * 0.5f, center.y),
                strokeWidth = 2f
            )
            drawLine(
                color = Color(0x33FFFFFF),
                start = Offset(center.x, center.y - radius * 0.5f),
                end = Offset(center.x, center.y + radius * 0.5f),
                strokeWidth = 2f
            )

            // Joystick Knob
            val knobCenter = center + knobOffset
            drawCircle(
                color = Color(0xFF9333EA),
                radius = 32f,
                center = knobCenter
            )
            drawCircle(
                color = Color(0xFFF43F5E),
                radius = 28f,
                center = knobCenter
            )
            drawCircle(
                color = Color.White,
                radius = 10f,
                center = knobCenter
            )
        }
    }
}
