package com.example.model

import org.json.JSONObject

sealed class PacketModel(val type: String) {
    abstract fun toJson(): JSONObject
    fun serialize(): String = toJson().toString()

    companion object {
        fun deserialize(raw: String): PacketModel? {
            return try {
                val json = JSONObject(raw)
                when (json.optString("type")) {
                    "MOVE" -> MovementPayload(
                        x = json.getDouble("x").toFloat(),
                        y = json.getDouble("y").toFloat(),
                        dir = json.optString("dir", "idle")
                    )
                    "ACTION" -> InteractionPayload(
                        actionId = json.getString("actionId"),
                        zone = json.optString("zone", "Garden"),
                        status = json.getString("status"),
                        timerSeconds = if (json.has("timerSeconds")) json.getInt("timerSeconds") else null
                    )
                    "HEARTBEAT" -> HeartbeatPayload(
                        timestamp = json.getLong("timestamp")
                    )
                    else -> null
                }
            } catch (e: Exception) {
                null
            }
        }
    }
}

data class MovementPayload(
    val x: Float,
    val y: Float,
    val dir: String = "idle"
) : PacketModel("MOVE") {
    override fun toJson(): JSONObject = JSONObject().apply {
        put("type", type)
        put("x", x.toDouble())
        put("y", y.toDouble())
        put("dir", dir)
    }
}

data class InteractionPayload(
    val actionId: String,
    val zone: String,
    val status: String, // "REQUEST", "ACCEPT", "DECLINE"
    val timerSeconds: Int? = null
) : PacketModel("ACTION") {
    override fun toJson(): JSONObject = JSONObject().apply {
        put("type", type)
        put("actionId", actionId)
        put("zone", zone)
        put("status", status)
        timerSeconds?.let { put("timerSeconds", it) }
    }
}

data class HeartbeatPayload(
    val timestamp: Long
) : PacketModel("HEARTBEAT") {
    override fun toJson(): JSONObject = JSONObject().apply {
        put("type", type)
        put("timestamp", timestamp)
    }
}
