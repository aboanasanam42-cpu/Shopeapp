import 'dart:convert';

/// Base class for all network packets exchanged between Host and Client
abstract class PacketModel {
  final String type;

  const PacketModel({required this.type});

  Map<String, dynamic> toJson();

  String serialize() => jsonEncode(toJson());

  static PacketModel fromJson(Map<String, dynamic> json) {
    final type = json['type'] as String?;
    switch (type) {
      case 'MOVE':
        return MovementPayload.fromJson(json);
      case 'ACTION':
        return InteractionPayload.fromJson(json);
      case 'HEARTBEAT':
        return HeartbeatPayload.fromJson(json);
      case 'HANDSHAKE':
        return HandshakePayload.fromJson(json);
      default:
        throw FormatException('Unknown packet type: $type');
    }
  }

  static PacketModel deserialize(String rawJson) {
    final Map<String, dynamic> decoded = jsonDecode(rawJson) as Map<String, dynamic>;
    return fromJson(decoded);
  }
}

/// Movement synchronization payload transmitted every 50ms
class MovementPayload extends PacketModel {
  final double x;
  final double y;
  final String dir; // 'idle', 'up', 'down', 'left', 'right', etc.

  const MovementPayload({
    required this.x,
    required this.y,
    required this.dir,
  }) : super(type: 'MOVE');

  factory MovementPayload.fromJson(Map<String, dynamic> json) {
    return MovementPayload(
      x: (json['x'] as num).toDouble(),
      y: (json['y'] as num).toDouble(),
      dir: (json['dir'] as String?) ?? 'idle',
    );
  }

  @override
  Map<String, dynamic> toJson() => {
        'type': type,
        'x': x,
        'y': y,
        'dir': dir,
      };
}

/// Mutual interaction payload (Hug, Kiss, Dance, Walk)
class InteractionPayload extends PacketModel {
  final String actionId; // 'HUG', 'KISS', 'DANCE', 'STROLL', 'CANCEL'
  final String zone;     // 'Garden', 'LivingRoom', 'Bedroom'
  final String status;   // 'REQUEST' | 'ACCEPT' | 'DECLINE' | 'COMPLETED'
  final int? timerSeconds;

  const InteractionPayload({
    required this.actionId,
    required this.zone,
    required this.status,
    this.timerSeconds,
  }) : super(type: 'ACTION');

  factory InteractionPayload.fromJson(Map<String, dynamic> json) {
    return InteractionPayload(
      actionId: json['actionId'] as String,
      zone: json['zone'] as String,
      status: json['status'] as String,
      timerSeconds: json['timerSeconds'] as int?,
    );
  }

  @override
  Map<String, dynamic> toJson() => {
        'type': type,
        'actionId': actionId,
        'zone': zone,
        'status': status,
        if (timerSeconds != null) 'timerSeconds': timerSeconds,
      };
}

/// Heartbeat ping to verify latency and keep connection alive
class HeartbeatPayload extends PacketModel {
  final int timestamp;

  const HeartbeatPayload({required this.timestamp}) : super(type: 'HEARTBEAT');

  factory HeartbeatPayload.fromJson(Map<String, dynamic> json) {
    return HeartbeatPayload(
      timestamp: (json['timestamp'] as num).toInt(),
    );
  }

  @override
  Map<String, dynamic> toJson() => {
        'type': type,
        'timestamp': timestamp,
      };
}

/// Handshake metadata sent on initial connection
class HandshakePayload extends PacketModel {
  final String playerName;
  final String role; // 'HOST' or 'CLIENT'
  final String avatarStyle;

  const HandshakePayload({
    required this.playerName,
    required this.role,
    required this.avatarStyle,
  }) : super(type: 'HANDSHAKE');

  factory HandshakePayload.fromJson(Map<String, dynamic> json) {
    return HandshakePayload(
      playerName: json['playerName'] as String? ?? 'Player',
      role: json['role'] as String? ?? 'CLIENT',
      avatarStyle: json['avatarStyle'] as String? ?? 'default',
    );
  }

  @override
  Map<String, dynamic> toJson() => {
        'type': type,
        'playerName': playerName,
        'role': role,
        'avatarStyle': avatarStyle,
      };
}
