import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:nearby_connections/nearby_connections.dart';
import 'packet_model.dart';

enum ConnectionState {
  disconnected,
  advertising,
  discovering,
  connecting,
  connected,
}

enum ConnectionMode {
  nearbyConnections,
  localSocket,
}

class DiscoveredPeer {
  final String endpointId;
  final String endpointName;
  DiscoveredPeer({required this.endpointId, required this.endpointName});
}

class ConnectionManager extends ChangeNotifier {
  static final ConnectionManager _instance = ConnectionManager._internal();
  factory ConnectionManager() => _instance;
  ConnectionManager._internal();

  static const String serviceId = 'com.aistudio.palacegame.p2p';
  static const Strategy defaultStrategy = Strategy.P2P_POINT_TO_POINT;
  static const int socketPort = 8888;

  ConnectionState _state = ConnectionState.disconnected;
  ConnectionState get state => _state;

  bool _isHost = false;
  bool get isHost => _isHost;

  String? _connectedEndpointId;
  String? get connectedEndpointId => _connectedEndpointId;

  String _localPlayerName = 'Host';
  String get localPlayerName => _localPlayerName;

  String _remotePlayerName = 'Partner';
  String get remotePlayerName => _remotePlayerName;

  final List<DiscoveredPeer> _discoveredPeers = [];
  List<DiscoveredPeer> get discoveredPeers => List.unmodifiable(_discoveredPeers);

  // Fallback TCP Socket references
  ServerSocket? _serverSocket;
  Socket? _clientSocket;

  // Streams for incoming data
  final _packetController = StreamController<PacketModel>.broadcast();
  Stream<PacketModel> get packetStream => _packetController.stream;

  final _movementController = StreamController<MovementPayload>.broadcast();
  Stream<MovementPayload> get movementStream => _movementController.stream;

  final _interactionController = StreamController<InteractionPayload>.broadcast();
  Stream<InteractionPayload> get interactionStream => _interactionController.stream;

  int _latencyMs = 0;
  int get latencyMs => _latencyMs;

  Timer? _heartbeatTimer;

  void setPlayerName(String name) {
    _localPlayerName = name;
    notifyListeners();
  }

  void _setState(ConnectionState newState) {
    _state = newState;
    notifyListeners();
  }

  // ==========================================
  // NEARBY CONNECTIONS (Bluetooth / Wi-Fi Direct)
  // ==========================================

  /// Start Advertising as Host (Room Creator)
  Future<bool> startHosting({required String roomName}) async {
    await disconnect();
    _isHost = true;
    _localPlayerName = roomName;
    _setState(ConnectionState.advertising);

    try {
      final bool success = await Nearby().startAdvertising(
        _localPlayerName,
        defaultStrategy,
        onConnectionInitiated: _onConnectionInitiated,
        onConnectionResult: _onConnectionResult,
        onDisconnected: _onDisconnected,
        serviceId: serviceId,
      );

      if (!success) {
        // Fallback to local socket server if Nearby is unavailable
        await _startSocketServer();
      }
      return true;
    } catch (e) {
      debugPrint('[ConnectionManager] Nearby Advertising error: $e, falling back to TCP socket');
      return await _startSocketServer();
    }
  }

  /// Start Discovering as Client (Joiner)
  Future<bool> startDiscovering() async {
    await disconnect();
    _isHost = false;
    _discoveredPeers.clear();
    _setState(ConnectionState.discovering);

    try {
      final bool success = await Nearby().startDiscovery(
        _localPlayerName,
        defaultStrategy,
        onEndpointFound: (endpointId, endpointName, serviceId) {
          debugPrint('[ConnectionManager] Endpoint found: $endpointName ($endpointId)');
          if (!_discoveredPeers.any((p) => p.endpointId == endpointId)) {
            _discoveredPeers.add(DiscoveredPeer(endpointId: endpointId, endpointName: endpointName));
            notifyListeners();
          }
        },
        onEndpointLost: (endpointId) {
          _discoveredPeers.removeWhere((p) => p.endpointId == endpointId);
          notifyListeners();
        },
        serviceId: serviceId,
      );
      return success;
    } catch (e) {
      debugPrint('[ConnectionManager] Nearby Discovery error: $e');
      return false;
    }
  }

  /// Request connection to a discovered endpoint
  Future<bool> connectToPeer(String endpointId) async {
    _setState(ConnectionState.connecting);
    try {
      await Nearby().requestConnection(
        _localPlayerName,
        endpointId,
        onConnectionInitiated: _onConnectionInitiated,
        onConnectionResult: _onConnectionResult,
        onDisconnected: _onDisconnected,
      );
      return true;
    } catch (e) {
      debugPrint('[ConnectionManager] Connection request error: $e');
      _setState(ConnectionState.disconnected);
      return false;
    }
  }

  void _onConnectionInitiated(String endpointId, ConnectionInfo info) {
    debugPrint('[ConnectionManager] Connection initiated with: ${info.endpointName}');
    _remotePlayerName = info.endpointName;
    // Auto-accept the connection for seamless pairing
    Nearby().acceptConnection(
      endpointId,
      onPayLoadRecieved: (endpointId, payload) {
        if (payload.type == PayloadType.BYTES && payload.bytes != null) {
          final String raw = utf8.decode(payload.bytes!);
          _handleRawPayload(raw);
        }
      },
    );
  }

  void _onConnectionResult(String endpointId, Status status) {
    debugPrint('[ConnectionManager] Connection result: $status');
    if (status == Status.CONNECTED) {
      _connectedEndpointId = endpointId;
      _setState(ConnectionState.connected);
      Nearby().stopAdvertising();
      Nearby().stopDiscovery();
      _startHeartbeat();
    } else {
      _setState(ConnectionState.disconnected);
    }
  }

  void _onDisconnected(String endpointId) {
    debugPrint('[ConnectionManager] Disconnected from: $endpointId');
    disconnect();
  }

  // ==========================================
  // TCP SOCKET FALLBACK (Local Wi-Fi / Hotspot)
  // ==========================================

  Future<bool> _startSocketServer() async {
    try {
      _serverSocket = await ServerSocket.bind(InternetAddress.anyIPv4, socketPort);
      _setState(ConnectionState.advertising);
      debugPrint('[ConnectionManager] TCP Server listening on port $socketPort');

      _serverSocket?.listen((socket) {
        _clientSocket = socket;
        _setupSocketListeners(socket);
        _setState(ConnectionState.connected);
        _startHeartbeat();
      });
      return true;
    } catch (e) {
      debugPrint('[ConnectionManager] TCP Server start error: $e');
      _setState(ConnectionState.disconnected);
      return false;
    }
  }

  Future<bool> connectViaSocket({required String hostIp}) async {
    await disconnect();
    _isHost = false;
    _setState(ConnectionState.connecting);

    try {
      _clientSocket = await Socket.connect(hostIp, socketPort, timeout: const Duration(seconds: 5));
      _setupSocketListeners(_clientSocket!);
      _setState(ConnectionState.connected);
      _startHeartbeat();
      return true;
    } catch (e) {
      debugPrint('[ConnectionManager] Socket connect error: $e');
      _setState(ConnectionState.disconnected);
      return false;
    }
  }

  void _setupSocketListeners(Socket socket) {
    socket.listen(
      (Uint8List data) {
        final String rawMessages = utf8.decode(data);
        for (final line in rawMessages.split('\n')) {
          if (line.trim().isNotEmpty) {
            _handleRawPayload(line.trim());
          }
        }
      },
      onDone: () => disconnect(),
      onError: (e) => disconnect(),
    );
  }

  // ==========================================
  // DATA TRANSMISSION
  // ==========================================

  void sendPayload(PacketModel packet) {
    final String serialized = packet.serialize();

    if (_state != ConnectionState.connected) return;

    // 1. Nearby Connections transmission
    if (_connectedEndpointId != null) {
      final bytes = Uint8List.fromList(utf8.encode(serialized));
      Nearby().sendBytesPayload(_connectedEndpointId!, bytes);
    }

    // 2. Fallback TCP Socket transmission
    if (_clientSocket != null) {
      _clientSocket?.write('$serialized\n');
    }
  }

  void sendMovement(double x, double y, String direction) {
    sendPayload(MovementPayload(x: x, y: y, dir: direction));
  }

  void sendInteraction({
    required String actionId,
    required String zone,
    required String status,
    int? timerSeconds,
  }) {
    sendPayload(InteractionPayload(
      actionId: actionId,
      zone: zone,
      status: status,
      timerSeconds: timerSeconds,
    ));
  }

  void _handleRawPayload(String raw) {
    try {
      final packet = PacketModel.deserialize(raw);
      _packetController.add(packet);

      if (packet is MovementPayload) {
        _movementController.add(packet);
      } else if (packet is InteractionPayload) {
        _interactionController.add(packet);
      } else if (packet is HeartbeatPayload) {
        final now = DateTime.now().millisecondsSinceEpoch;
        _latencyMs = now - packet.timestamp;
        notifyListeners();
      }
    } catch (e) {
      debugPrint('[ConnectionManager] Failed to parse incoming packet: $e');
    }
  }

  void _startHeartbeat() {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = Timer.periodic(const Duration(seconds: 2), (_) {
      if (_state == ConnectionState.connected) {
        sendPayload(HeartbeatPayload(timestamp: DateTime.now().millisecondsSinceEpoch));
      }
    });
  }

  Future<void> disconnect() async {
    _heartbeatTimer?.cancel();
    try {
      if (_connectedEndpointId != null) {
        await Nearby().disconnectFromEndpoint(_connectedEndpointId!);
      }
      await Nearby().stopAllEndpoints();
      await Nearby().stopAdvertising();
      await Nearby().stopDiscovery();
    } catch (_) {}

    try {
      _clientSocket?.destroy();
      _clientSocket = null;
      await _serverSocket?.close();
      _serverSocket = null;
    } catch (_) {}

    _connectedEndpointId = null;
    _discoveredPeers.clear();
    _setState(ConnectionState.disconnected);
  }

  @override
  void dispose() {
    disconnect();
    _packetController.close();
    _movementController.close();
    _interactionController.close();
    super.dispose();
  }
}
