import 'dart:async';
import 'dart:math' as math;
import 'package:flame/events.dart';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import '../network/connection_manager.dart';
import '../network/packet_model.dart';
import 'components/player_avatar.dart';
import 'components/remote_player.dart';
import 'components/zone_trigger.dart';

class PalaceGame extends FlameGame with TapCallbacks, DragCallbacks {
  late PlayerAvatar player;
  late RemotePlayer remotePlayer;

  final List<ZoneTrigger> zones = [];
  String currentZone = 'Garden';

  // Proximity configuration
  static const double proximityThreshold = 50.0; // R <= 50px
  bool isWithinProximity = false;
  double currentDistance = 999.0;

  // Callbacks to UI overlays
  final Function(bool inRange, double distance, String currentZone) onProximityChanged;
  final Function(String actionId, String partnerName, int? duration) onInteractionReceived;

  StreamSubscription<MovementPayload>? _movementSub;
  StreamSubscription<InteractionPayload>? _interactionSub;

  PalaceGame({
    required this.onProximityChanged,
    required this.onInteractionReceived,
  });

  @override
  Color backgroundColor() => const Color(0xFF1A1A24);

  @override
  Future<void> onLoad() async {
    super.onLoad();

    // 1. Initialize Map Zones
    // Map dimensions: 800 x 900
    final gardenZone = ZoneTrigger(
      zoneType: ZoneType.garden,
      label: 'Royal Garden',
      position: Vector2(20, 20),
      size: Vector2(760, 320),
    );

    final livingRoomZone = ZoneTrigger(
      zoneType: ZoneType.livingRoom,
      label: 'Grand Hall & Living Room',
      position: Vector2(20, 360),
      size: Vector2(370, 480),
    );

    final bedroomZone = ZoneTrigger(
      zoneType: ZoneType.bedroom,
      label: 'Royal Bedroom Suite',
      position: Vector2(410, 360),
      size: Vector2(370, 480),
    );

    zones.addAll([gardenZone, livingRoomZone, bedroomZone]);
    for (final zone in zones) {
      add(zone);
    }

    // 2. Add Players
    final isHost = ConnectionManager().isHost;
    player = PlayerAvatar(
      name: ConnectionManager().localPlayerName,
      avatarColor: isHost ? const Color(0xFF7C3AED) : const Color(0xFFEC4899),
      startPosition: isHost ? Vector2(180, 180) : Vector2(240, 180),
      isLocal: true,
    );

    remotePlayer = RemotePlayer(
      name: ConnectionManager().remotePlayerName,
      avatarColor: isHost ? const Color(0xFFEC4899) : const Color(0xFF7C3AED),
      startPosition: isHost ? Vector2(240, 180) : Vector2(180, 180),
    );

    add(remotePlayer);
    add(player);

    // 3. Setup Network Listeners
    _movementSub = ConnectionManager().movementStream.listen((move) {
      remotePlayer.updateTargetPosition(move.x, move.y, move.dir);
    });

    _interactionSub = ConnectionManager().interactionStream.listen((action) {
      _handleNetworkAction(action);
    });
  }

  void updateJoystickVelocity(Vector2 dir) {
    player.velocity = dir;
  }

  @override
  void update(double dt) {
    super.update(dt);

    // Keep player within palace bounds (20..780, 20..840)
    player.position.x = player.position.x.clamp(30.0, 770.0);
    player.position.y = player.position.y.clamp(30.0, 830.0);

    // 1. Detect Active Zone
    for (final zone in zones) {
      if (zone.containsPoint(player.position)) {
        currentZone = zone.zoneType.title;
        break;
      }
    }

    // 2. Proximity Detection: Euclidean Distance R <= 50px
    final dx = player.position.x - remotePlayer.position.x;
    final dy = player.position.y - remotePlayer.position.y;
    currentDistance = math.sqrt(dx * dx + dy * dy);

    final bool inRange = currentDistance <= proximityThreshold;
    if (inRange != isWithinProximity) {
      isWithinProximity = inRange;
      onProximityChanged(isWithinProximity, currentDistance, currentZone);
    }
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);

    // Draw proximity visual aura when near
    if (isWithinProximity) {
      final linePaint = Paint()
        ..color = Colors.pinkAccent.withOpacity(0.6)
        ..strokeWidth = 2.0
        ..style = PaintingStyle.stroke;

      canvas.drawLine(
        Offset(player.position.x, player.position.y),
        Offset(remotePlayer.position.x, remotePlayer.position.y),
        linePaint,
      );

      final auraPaint = Paint()
        ..color = Colors.pinkAccent.withOpacity(0.15)
        ..style = PaintingStyle.fill;

      canvas.drawCircle(
        Offset(player.position.x, player.position.y),
        proximityThreshold,
        auraPaint,
      );
    }
  }

  void _handleNetworkAction(InteractionPayload action) {
    if (action.status == 'REQUEST') {
      onInteractionReceived(action.actionId, remotePlayer.name, action.timerSeconds);
    } else if (action.status == 'ACCEPT') {
      triggerSharedActionAnimation(action.actionId);
    }
  }

  void triggerSharedActionAnimation(String actionId) {
    String emote = '💖';
    if (actionId == 'HUG') emote = '🤗';
    if (actionId == 'KISS') emote = '💋';
    if (actionId == 'DANCE') emote = '💃';
    if (actionId == 'STROLL') emote = '🌸';

    player.triggerEmote(emote, duration: 4.0);
    remotePlayer.triggerEmote(emote, duration: 4.0);
  }

  @override
  void onRemove() {
    _movementSub?.cancel();
    _interactionSub?.cancel();
    super.onRemove();
  }
}
