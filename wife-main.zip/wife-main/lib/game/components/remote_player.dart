import 'dart:math' as math;
import 'dart:ui';
import 'package:flame/components.dart';
import 'package:flutter/material.dart';

class RemotePlayer extends PositionComponent {
  final String name;
  final Color avatarColor;

  Vector2 targetPosition;
  String direction = 'idle';
  double lerpSpeed = 12.0; // Smooth position interpolation

  double _animTime = 0.0;
  bool isMoving = false;

  String? activeEmote;
  double emoteDuration = 0.0;

  RemotePlayer({
    required this.name,
    required this.avatarColor,
    required Vector2 startPosition,
  })  : targetPosition = startPosition.clone(),
        super(
          position: startPosition,
          size: Vector2(40, 48),
          anchor: Anchor.center,
          priority: 9,
        );

  void updateTargetPosition(double x, double y, String newDirection) {
    targetPosition.setValues(x, y);
    direction = newDirection;
    isMoving = (position.distanceTo(targetPosition) > 2.0);
  }

  void triggerEmote(String emote, {double duration = 3.0}) {
    activeEmote = emote;
    emoteDuration = duration;
  }

  @override
  void update(double dt) {
    super.update(dt);

    if (emoteDuration > 0) {
      emoteDuration -= dt;
      if (emoteDuration <= 0) activeEmote = null;
    }

    // Smooth Lerp towards target position
    final distance = position.distanceTo(targetPosition);
    if (distance > 1.0) {
      position.lerp(targetPosition, (lerpSpeed * dt).clamp(0.0, 1.0));
      isMoving = true;
      _animTime += dt * 8;
    } else {
      isMoving = false;
      _animTime = 0.0;
    }
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);

    final double walkBob = isMoving ? math.sin(_animTime) * 3 : 0;

    // 1. Shadow
    final shadowPaint = Paint()..color = Colors.black.withOpacity(0.25);
    canvas.drawOval(
      Rect.fromCenter(center: Offset(size.x / 2, size.y - 2), width: 34, height: 12),
      shadowPaint,
    );

    // 2. Body / Dress / Outfit
    final bodyPaint = Paint()..color = avatarColor;
    final bodyRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(8, 16 + walkBob, 24, 26),
      const Radius.circular(8),
    );
    canvas.drawRRect(bodyRect, bodyPaint);

    // Rose gold royal trim
    canvas.drawRect(
      Rect.fromLTWH(8, 28 + walkBob, 24, 4),
      Paint()..color = Colors.amberAccent,
    );

    // 3. Head & Hair
    final headCenter = Offset(size.x / 2, 12 + walkBob);
    final skinPaint = Paint()..color = const Color(0xFFFFDBAC);
    canvas.drawCircle(headCenter, 11, skinPaint);

    final hairPaint = Paint()..color = avatarColor.withBlue((avatarColor.blue * 0.8).toInt());
    canvas.drawArc(
      Rect.fromCircle(center: headCenter, radius: 12),
      math.pi,
      math.pi,
      true,
      hairPaint,
    );

    // Tiara jewel
    canvas.drawCircle(Offset(size.x / 2, 3 + walkBob), 3, Paint()..color = Colors.pinkAccent);

    // 4. Eyes
    final eyePaint = Paint()..color = Colors.black87;
    double eyeOffsetX = 0;
    if (direction == 'left') eyeOffsetX = -3;
    if (direction == 'right') eyeOffsetX = 3;

    canvas.drawCircle(headCenter + Offset(-3 + eyeOffsetX, 0), 1.5, eyePaint);
    canvas.drawCircle(headCenter + Offset(3 + eyeOffsetX, 0), 1.5, eyePaint);

    // 5. Name Tag
    final textSpan = TextSpan(
      text: '$name (P2P)',
      style: const TextStyle(
        color: Colors.white,
        fontSize: 10,
        fontWeight: FontWeight.bold,
        shadows: [Shadow(color: Colors.black, blurRadius: 3)],
      ),
    );
    final textPainter = TextPainter(
      text: textSpan,
      textDirection: TextDirection.ltr,
    )..layout();

    final tagWidth = textPainter.width + 10;
    final tagRect = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: Offset(size.x / 2, -10 + walkBob),
        width: tagWidth,
        height: 14,
      ),
      const Radius.circular(4),
    );
    canvas.drawRRect(tagRect, Paint()..color = Colors.indigo.withOpacity(0.75));
    textPainter.paint(
      canvas,
      Offset(size.x / 2 - textPainter.width / 2, -16 + walkBob),
    );

    // 6. Active Emote Bubble
    if (activeEmote != null) {
      final bubbleCenter = Offset(size.x / 2, -32 + walkBob);
      canvas.drawCircle(bubbleCenter, 14, Paint()..color = Colors.white);
      canvas.drawCircle(bubbleCenter, 14, Paint()..color = Colors.indigoAccent..style = PaintingStyle.stroke..strokeWidth = 2);

      final textSpan = TextSpan(
        text: activeEmote,
        style: const TextStyle(fontSize: 16),
      );
      final textPainter = TextPainter(
        text: textSpan,
        textDirection: TextDirection.ltr,
      )..layout();

      textPainter.paint(
        canvas,
        bubbleCenter - Offset(textPainter.width / 2, textPainter.height / 2),
      );
    }
  }
}
