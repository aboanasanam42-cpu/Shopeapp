import 'dart:math' as math;
import 'dart:ui';
import 'package:flame/components.dart';
import 'package:flutter/material.dart';
import '../../network/connection_manager.dart';

class PlayerAvatar extends PositionComponent {
  final String name;
  final Color avatarColor;
  final bool isLocal;

  Vector2 velocity = Vector2.zero();
  double speed = 160.0; // pixels per second
  String direction = 'idle';

  // Network position streaming timer (50ms interval = 20Hz)
  double _syncAccumulator = 0.0;
  static const double syncInterval = 0.050; // 50ms

  // Walking animation bob
  double _animTime = 0.0;

  // Active interaction emote
  String? activeEmote;
  double emoteDuration = 0.0;

  PlayerAvatar({
    required this.name,
    required this.avatarColor,
    required Vector2 startPosition,
    this.isLocal = true,
  }) : super(
          position: startPosition,
          size: Vector2(40, 48),
          anchor: Anchor.center,
          priority: 10,
        );

  void triggerEmote(String emote, {double duration = 3.0}) {
    activeEmote = emote;
    emoteDuration = duration;
  }

  @override
  void update(double dt) {
    super.update(dt);

    if (emoteDuration > 0) {
      emoteDuration -= dt;
      if (emoteDuration <= 0) activeEmote = null;
    }

    if (!isLocal) return;

    if (!velocity.isZero()) {
      _animTime += dt * 8;
      position.add(velocity * speed * dt);

      // Determine compass direction
      if (velocity.x.abs() > velocity.y.abs()) {
        direction = velocity.x > 0 ? 'right' : 'left';
      } else {
        direction = velocity.y > 0 ? 'down' : 'up';
      }
    } else {
      direction = 'idle';
      _animTime = 0.0;
    }

    // Position streaming every 50ms
    _syncAccumulator += dt;
    if (_syncAccumulator >= syncInterval) {
      _syncAccumulator = 0.0;
      ConnectionManager().sendMovement(position.x, position.y, direction);
    }
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);

    final double walkBob = !velocity.isZero() ? math.sin(_animTime) * 3 : 0;

    // 1. Soft shadow on ground
    final shadowPaint = Paint()..color = Colors.black.withOpacity(0.25);
    canvas.drawOval(
      Rect.fromCenter(center: Offset(size.x / 2, size.y - 2), width: 34, height: 12),
      shadowPaint,
    );

    // 2. Body / Cape
    final bodyPaint = Paint()..color = avatarColor;
    final bodyRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(8, 16 + walkBob, 24, 26),
      const Radius.circular(8),
    );
    canvas.drawRRect(bodyRect, bodyPaint);

    // Belt / royal accent
    canvas.drawRect(
      Rect.fromLTWH(8, 28 + walkBob, 24, 4),
      Paint()..color = Colors.amber,
    );

    // 3. Head & Hair
    final headCenter = Offset(size.x / 2, 12 + walkBob);
    final skinPaint = Paint()..color = const Color(0xFFFFDBAC);
    canvas.drawCircle(headCenter, 11, skinPaint);

    // Crown / Hair
    final hairPaint = Paint()..color = avatarColor.withRed((avatarColor.red * 0.7).toInt());
    canvas.drawArc(
      Rect.fromCircle(center: headCenter, radius: 12),
      math.pi,
      math.pi,
      true,
      hairPaint,
    );

    // Crown jewel
    canvas.drawCircle(Offset(size.x / 2, 3 + walkBob), 3, Paint()..color = Colors.amberAccent);

    // 4. Eyes based on direction
    final eyePaint = Paint()..color = Colors.black87;
    double eyeOffsetX = 0;
    if (direction == 'left') eyeOffsetX = -3;
    if (direction == 'right') eyeOffsetX = 3;

    canvas.drawCircle(headCenter + Offset(-3 + eyeOffsetX, 0), 1.5, eyePaint);
    canvas.drawCircle(headCenter + Offset(3 + eyeOffsetX, 0), 1.5, eyePaint);

    // 5. Name tag banner above head
    final textSpan = TextSpan(
      text: name,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 10,
        fontWeight: FontWeight.bold,
        shadows: [Shadow(color: Colors.black, blurRadius: 3)],
      ),
    );
    final textPainter = TextPainter(
      text: textSpan,
      textDirection: TextDirection.ltr,
    )..layout();

    final tagWidth = textPainter.width + 10;
    final tagRect = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: Offset(size.x / 2, -10 + walkBob),
        width: tagWidth,
        height: 14,
      ),
      const Radius.circular(4),
    );
    canvas.drawRRect(tagRect, Paint()..color = Colors.black54);
    textPainter.paint(
      canvas,
      Offset(size.x / 2 - textPainter.width / 2, -16 + walkBob),
    );

    // 6. Active Emote Bubble
    if (activeEmote != null) {
      _renderEmoteBubble(canvas, walkBob);
    }
  }

  void _renderEmoteBubble(Canvas canvas, double walkBob) {
    final bubbleCenter = Offset(size.x / 2, -32 + walkBob);
    canvas.drawCircle(bubbleCenter, 14, Paint()..color = Colors.white);
    canvas.drawCircle(bubbleCenter, 14, Paint()..color = Colors.pinkAccent..style = PaintingStyle.stroke..strokeWidth = 2);

    final textSpan = TextSpan(
      text: activeEmote,
      style: const TextStyle(fontSize: 16),
    );
    final textPainter = TextPainter(
      text: textSpan,
      textDirection: TextDirection.ltr,
    )..layout();

    textPainter.paint(
      canvas,
      bubbleCenter - Offset(textPainter.width / 2, textPainter.height / 2),
    );
  }
}
