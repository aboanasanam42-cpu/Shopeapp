import 'dart:ui';
import 'package:flame/components.dart';
import 'package:flutter/material.dart';

enum ZoneType {
  garden('Garden', Color(0xFF2E7D32), Color(0xFF1B5E20)),
  livingRoom('LivingRoom', Color(0xFF8D6E63), Color(0xFF5D4037)),
  bedroom('Bedroom', Color(0xFF4A148C), Color(0xFF311B92));

  final String title;
  final Color primaryColor;
  final Color borderColor;

  const ZoneType(this.title, this.primaryColor, this.borderColor);
}

class ZoneTrigger extends PositionComponent {
  final ZoneType zoneType;
  final String label;

  ZoneTrigger({
    required this.zoneType,
    required this.label,
    required Vector2 position,
    required Vector2 size,
  }) : super(position: position, size: size, priority: 0);

  bool containsPoint(Vector2 point) {
    return point.x >= position.x &&
        point.x <= position.x + size.x &&
        point.y >= position.y &&
        point.y <= position.y + size.y;
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);

    final rect = Rect.fromLTWH(0, 0, size.x, size.y);
    final bgPaint = Paint()
      ..color = zoneType.primaryColor.withOpacity(0.25)
      ..style = PaintingStyle.fill;

    final borderPaint = Paint()
      ..color = zoneType.borderColor.withOpacity(0.8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.0;

    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(8)), bgPaint);
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(8)), borderPaint);

    // Render floor pattern / atmosphere based on zone
    _renderZoneAtmosphere(canvas, rect);

    // Label on top
    final textPainter = TextPainter(
      text: TextSpan(
        text: '📍 ${zoneType.title}',
        style: TextStyle(
          color: zoneType.borderColor,
          fontSize: 16,
          fontWeight: FontWeight.bold,
          shadows: const [
            Shadow(color: Colors.white, blurRadius: 4),
          ],
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();

    textPainter.paint(canvas, const Offset(12, 10));
  }

  void _renderZoneAtmosphere(Canvas canvas, Rect rect) {
    final decorPaint = Paint()..style = PaintingStyle.stroke..strokeWidth = 1.0;

    if (zoneType == ZoneType.garden) {
      // Draw fountain circle in center
      final center = Offset(rect.width / 2, rect.height / 2);
      final fountainPaint = Paint()..color = Colors.lightBlue.withOpacity(0.4)..style = PaintingStyle.fill;
      canvas.drawCircle(center, 40, fountainPaint);
      decorPaint.color = Colors.lightBlueAccent;
      canvas.drawCircle(center, 40, decorPaint);
      canvas.drawCircle(center, 25, decorPaint);

      // Rose bushes dots
      final flowerPaint = Paint()..color = Colors.pinkAccent;
      canvas.drawCircle(const Offset(30, 40), 6, flowerPaint);
      canvas.drawCircle(const Offset(60, 50), 6, flowerPaint);
      canvas.drawCircle(Offset(rect.width - 40, 40), 6, flowerPaint);
      canvas.drawCircle(Offset(rect.width - 60, 70), 6, flowerPaint);
    } else if (zoneType == ZoneType.livingRoom) {
      // Fireplace on north wall
      final fireplace = Rect.fromLTWH(rect.width / 2 - 35, 2, 70, 24);
      canvas.drawRect(fireplace, Paint()..color = Colors.brown[900]!);
      canvas.drawCircle(fireplace.center, 8, Paint()..color = Colors.orangeAccent);

      // Velvet rug
      final rug = Rect.fromCenter(center: Offset(rect.width / 2, rect.height / 2), width: 140, height: 90);
      canvas.drawRRect(RRect.fromRectAndRadius(rug, const Radius.circular(12)), Paint()..color = const Color(0xFFB71C1C).withOpacity(0.4));
    } else if (zoneType == ZoneType.bedroom) {
      // Canopy bed
      final bed = Rect.fromLTWH(20, 20, 70, 100);
      canvas.drawRRect(RRect.fromRectAndRadius(bed, const Radius.circular(6)), Paint()..color = Colors.indigo[800]!.withOpacity(0.6));
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(25, 25, 60, 25), const Radius.circular(4)), Paint()..color = Colors.white70);

      // Soft balcony glow
      final balcony = Rect.fromLTWH(rect.width - 30, rect.height / 2 - 40, 26, 80);
      canvas.drawRect(balcony, Paint()..color = Colors.amber.withOpacity(0.3));
    }
  }
}
