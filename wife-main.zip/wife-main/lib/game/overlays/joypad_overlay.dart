import 'dart:math' as math;
import 'package:flame/game.dart';
import 'package:flutter/material.dart';

class JoypadOverlay extends StatefulWidget {
  final Function(Vector2 direction) onDirectionChanged;

  const JoypadOverlay({Key? key, required this.onDirectionChanged}) : super(key: key);

  @override
  State<JoypadOverlay> createState() => _JoypadOverlayState();
}

class _JoypadOverlayState extends State<JoypadOverlay> {
  Offset _dragPosition = Offset.zero;
  static const double _radius = 60.0;
  static const double _knobRadius = 25.0;

  void _updateOffset(Offset localPosition) {
    final center = const Offset(_radius, _radius);
    final delta = localPosition - center;
    final distance = delta.distance;

    Offset clampedDelta;
    if (distance > _radius) {
      clampedDelta = Offset(
        (delta.dx / distance) * _radius,
        (delta.dy / distance) * _radius,
      );
    } else {
      clampedDelta = delta;
    }

    setState(() {
      _dragPosition = clampedDelta;
    });

    final normalized = Vector2(
      clampedDelta.dx / _radius,
      clampedDelta.dy / _radius,
    );
    widget.onDirectionChanged(normalized);
  }

  void _reset() {
    setState(() {
      _dragPosition = Offset.zero;
    });
    widget.onDirectionChanged(Vector2.zero());
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onPanStart: (details) => _updateOffset(details.localPosition),
      onPanUpdate: (details) => _updateOffset(details.localPosition),
      onPanEnd: (_) => _reset(),
      onPanCancel: () => _reset(),
      child: Container(
        width: _radius * 2,
        height: _radius * 2,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.black.withOpacity(0.35),
          border: Border.all(color: Colors.white24, width: 2),
          boxShadow: [
            BoxShadow(
              color: Colors.purple.withOpacity(0.2),
              blurRadius: 10,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Center directional guide cross
            Icon(Icons.add, color: Colors.white12, size: 40),
            // Joystick Knob
            Transform.translate(
              offset: _dragPosition,
              child: Container(
                width: _knobRadius * 2,
                height: _knobRadius * 2,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const RadialGradient(
                    colors: [Color(0xFFE879F9), Color(0xFF9333EA)],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.purpleAccent.withOpacity(0.6),
                      blurRadius: 8,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.drag_indicator,
                  color: Colors.white,
                  size: 20,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
