import 'dart:async';
import 'package:flutter/material.dart';
import '../../network/connection_manager.dart';

class InteractionModal extends StatefulWidget {
  final String activeZone;
  final VoidCallback onClose;
  final Function(String actionId, int? timerSeconds) onActionConfirmed;

  const InteractionModal({
    Key? key,
    required this.activeZone,
    required this.onClose,
    required this.onActionConfirmed,
  }) : super(key: key);

  @override
  State<InteractionModal> createState() => _InteractionModalState();
}

class _InteractionModalState extends State<InteractionModal> {
  String? selectedAction;
  int selectedTimerSeconds = 30;
  bool includeTimer = true;

  final List<Map<String, dynamic>> actions = [
    {
      'id': 'HUG',
      'title': 'Warm Embrace',
      'icon': '🤗',
      'desc': 'Hold each other close in the palace.',
      'color': const Color(0xFFF43F5E),
    },
    {
      'id': 'KISS',
      'title': 'Sweet Kiss',
      'icon': '💋',
      'desc': 'A tender moment under the chandeliers.',
      'color': const Color(0xFFE11D48),
    },
    {
      'id': 'DANCE',
      'title': 'Royal Waltz',
      'icon': '💃',
      'desc': 'Slow dance to the palace melody.',
      'color': const Color(0xFF8B5CF6),
    },
    {
      'id': 'STROLL',
      'title': 'Moonlit Stroll',
      'icon': '🌸',
      'desc': 'Walk hand in hand around the fountain.',
      'color': const Color(0xFF10B981),
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Material(
        color: Colors.transparent,
        child: Container(
          width: 360,
          margin: const EdgeInsets.symmetric(horizontal: 20),
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: const Color(0xFF1E1B2E).withOpacity(0.96),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: const Color(0xFFE879F9).withOpacity(0.4), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: Colors.pink.withOpacity(0.3),
                blurRadius: 24,
                spreadRadius: 4,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Header
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.pink.withOpacity(0.2),
                      shape: BoxShape.circle,
                    ),
                    child: const Text('✨', style: TextStyle(fontSize: 22)),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Proximity Interaction',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          'Active in ${widget.activeZone}',
                          style: TextStyle(
                            color: Colors.pinkAccent.shade100,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white60),
                    onPressed: widget.onClose,
                  ),
                ],
              ),
              const SizedBox(height: 18),

              // Action Selection Grid
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 1.4,
                ),
                itemCount: actions.length,
                itemBuilder: (context, index) {
                  final item = actions[index];
                  final isSelected = selectedAction == item['id'];
                  return InkWell(
                    onTap: () {
                      setState(() {
                        selectedAction = item['id'];
                      });
                    },
                    borderRadius: BorderRadius.circular(16),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? (item['color'] as Color).withOpacity(0.25)
                            : Colors.white.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: isSelected
                              ? (item['color'] as Color)
                              : Colors.white12,
                          width: isSelected ? 2.0 : 1.0,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(item['icon'], style: const TextStyle(fontSize: 24)),
                          const Spacer(),
                          Text(
                            item['title'],
                            style: TextStyle(
                              color: isSelected ? Colors.white : Colors.white70,
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),

              const SizedBox(height: 16),

              // Synchronized Timer Option
              Row(
                children: [
                  Checkbox(
                    value: includeTimer,
                    activeColor: Colors.pinkAccent,
                    onChanged: (val) {
                      setState(() {
                        includeTimer = val ?? true;
                      });
                    },
                  ),
                  const Text(
                    'Synchronized Timer:',
                    style: TextStyle(color: Colors.white70, fontSize: 13),
                  ),
                  const Spacer(),
                  DropdownButton<int>(
                    value: selectedTimerSeconds,
                    dropdownColor: const Color(0xFF2A2438),
                    style: const TextStyle(color: Colors.white, fontSize: 13),
                    items: const [
                      DropdownMenuItem(value: 15, child: Text('15s')),
                      DropdownMenuItem(value: 30, child: Text('30s')),
                      DropdownMenuItem(value: 60, child: Text('60s')),
                      DropdownMenuItem(value: 120, child: Text('2 min')),
                    ],
                    onChanged: includeTimer
                        ? (val) {
                            if (val != null) setState(() => selectedTimerSeconds = val);
                          }
                        : null,
                  ),
                ],
              ),

              const SizedBox(height: 16),

              // Action Button
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFE11D48),
                    disabledBackgroundColor: Colors.white12,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  onPressed: selectedAction == null
                      ? null
                      : () {
                          final duration = includeTimer ? selectedTimerSeconds : null;
                          ConnectionManager().sendInteraction(
                            actionId: selectedAction!,
                            zone: widget.activeZone,
                            status: 'REQUEST',
                            timerSeconds: duration,
                          );
                          widget.onActionConfirmed(selectedAction!, duration);
                          widget.onClose();
                        },
                  child: const Text(
                    'Send Interaction Request 💕',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
