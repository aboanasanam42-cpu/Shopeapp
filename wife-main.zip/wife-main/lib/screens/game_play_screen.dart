import 'dart:async';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../game/overlays/interaction_modal.dart';
import '../game/overlays/joypad_overlay.dart';
import '../game/palace_game.dart';
import '../network/connection_manager.dart';
import 'lobby_screen.dart';

class GamePlayScreen extends StatefulWidget {
  const GamePlayScreen({Key? key}) : super(key: key);

  @override
  State<GamePlayScreen> createState() => _GamePlayScreenState();
}

class _GamePlayScreenState extends State<GamePlayScreen> with SingleTickerProviderStateMixin {
  late PalaceGame _game;

  bool _isProximityActive = false;
  double _distance = 999.0;
  String _activeZone = 'Garden';
  bool _showInteractionModal = false;

  // Incoming action request dialog
  String? _incomingAction;
  String? _incomingRequester;
  int? _incomingDuration;

  // Active synchronized timer & animation
  String? _activeCelebrationAction;
  int _remainingTimer = 0;
  Timer? _celebrationCountdown;

  @override
  void initState() {
    super.initState();
    _game = PalaceGame(
      onProximityChanged: (inRange, dist, zone) {
        setState(() {
          _isProximityActive = inRange;
          _distance = dist;
          _activeZone = zone;
        });
      },
      onInteractionReceived: (actionId, partner, duration) {
        setState(() {
          _incomingAction = actionId;
          _incomingRequester = partner;
          _incomingDuration = duration;
        });
      },
    );
  }

  void _startSynchronizedCelebration(String actionId, int? seconds) {
    setState(() {
      _activeCelebrationAction = actionId;
      _remainingTimer = seconds ?? 0;
    });

    _game.triggerSharedActionAnimation(actionId);

    if (seconds != null && seconds > 0) {
      _celebrationCountdown?.cancel();
      _celebrationCountdown = Timer.periodic(const Duration(seconds: 1), (timer) {
        if (!mounted) return;
        setState(() {
          if (_remainingTimer > 0) {
            _remainingTimer--;
          } else {
            _activeCelebrationAction = null;
            timer.cancel();
          }
        });
      });
    }
  }

  @override
  void dispose() {
    _celebrationCountdown?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final conn = Provider.of<ConnectionManager>(context);

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // 1. Flame 2D Game Canvas
          GameWidget(game: _game),

          // 2. Top Game HUD
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Row(
                children: [
                  // Zone Badge
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1E1B2E).withOpacity(0.9),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.white24),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.castle, color: Colors.amber, size: 18),
                        const SizedBox(width: 8),
                        Text(
                          _activeZone,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const Spacer(),

                  // Latency & Connection indicator
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.green.withOpacity(0.5)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 8,
                          height: 8,
                          decoration: const BoxDecoration(color: Colors.greenAccent, shape: BoxShape.circle),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          '${conn.latencyMs} ms',
                          style: const TextStyle(color: Colors.white70, fontSize: 11),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(width: 8),

                  // Exit / Disconnect Button
                  IconButton(
                    icon: const Icon(Icons.exit_to_app, color: Colors.white70),
                    onPressed: () {
                      conn.disconnect();
                      Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (_) => const LobbyScreen()),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),

          // 3. Proximity Romantic Action Button (Pulsing when R <= 50px)
          if (_isProximityActive)
            Positioned(
              bottom: 160,
              right: 24,
              child: TweenAnimationBuilder<double>(
                tween: Tween(begin: 0.9, end: 1.1),
                duration: const Duration(milliseconds: 600),
                curve: Curves.easeInOut,
                builder: (context, scale, child) {
                  return Transform.scale(
                    scale: scale,
                    child: FloatingActionButton.extended(
                      backgroundColor: const Color(0xFFE11D48),
                      elevation: 8,
                      icon: const Icon(Icons.favorite, color: Colors.white),
                      label: const Text(
                        'Interact 💕',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                      onPressed: () {
                        setState(() {
                          _showInteractionModal = true;
                        });
                      },
                    ),
                  );
                },
              ),
            ),

          // 4. Virtual Joypad Overlay (Bottom Left)
          Positioned(
            bottom: 30,
            left: 30,
            child: JoypadOverlay(
              onDirectionChanged: (dir) {
                _game.updateJoystickVelocity(dir);
              },
            ),
          ),

          // 5. Interaction Selection Modal Overlay
          if (_showInteractionModal)
            InteractionModal(
              activeZone: _activeZone,
              onClose: () => setState(() => _showInteractionModal = false),
              onActionConfirmed: (actionId, timerSec) {
                _startSynchronizedCelebration(actionId, timerSec);
              },
            ),

          // 6. Incoming Interaction Request Alert
          if (_incomingAction != null)
            _buildIncomingRequestDialog(conn),

          // 7. Synchronized Timer / Celebration Banner
          if (_activeCelebrationAction != null)
            _buildCelebrationOverlay(),
        ],
      ),
    );
  }

  Widget _buildIncomingRequestDialog(ConnectionManager conn) {
    String actionName = _incomingAction ?? 'Action';
    String emoji = '💖';
    if (_incomingAction == 'HUG') emoji = '🤗';
    if (_incomingAction == 'KISS') emoji = '💋';
    if (_incomingAction == 'DANCE') emoji = '💃';
    if (_incomingAction == 'STROLL') emoji = '🌸';

    return Center(
      child: Material(
        color: Colors.transparent,
        child: Container(
          width: 320,
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: const Color(0xFF1E182A),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.pinkAccent, width: 2),
            boxShadow: [
              BoxShadow(
                color: Colors.pink.withOpacity(0.4),
                blurRadius: 20,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(emoji, style: const TextStyle(fontSize: 48)),
              const SizedBox(height: 12),
              Text(
                '$_incomingRequester sent an invitation!',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 6),
              Text(
                'Wants to share a $actionName in $_activeZone',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70, fontSize: 13),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Colors.white30),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: () {
                        setState(() => _incomingAction = null);
                        conn.sendInteraction(
                          actionId: actionName,
                          zone: _activeZone,
                          status: 'DECLINE',
                        );
                      },
                      child: const Text('Decline', style: TextStyle(color: Colors.white70)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFE11D48),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: () {
                        conn.sendInteraction(
                          actionId: actionName,
                          zone: _activeZone,
                          status: 'ACCEPT',
                          timerSeconds: _incomingDuration,
                        );
                        _startSynchronizedCelebration(actionName, _incomingDuration);
                        setState(() => _incomingAction = null);
                      },
                      child: const Text('Accept 💕', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCelebrationOverlay() {
    return Positioned(
      top: 90,
      left: 20,
      right: 20,
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF831843), Color(0xFF701A75)],
            ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.pink.withOpacity(0.5),
                blurRadius: 16,
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('✨', style: TextStyle(fontSize: 20)),
              const SizedBox(width: 8),
              Text(
                'Synchronized ${_activeCelebrationAction!} Active',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
              ),
              if (_remainingTimer > 0) ...[
                const SizedBox(width: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.black45,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '$_remainingTimer s',
                    style: const TextStyle(color: Colors.amberAccent, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
