import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../network/connection_manager.dart';
import 'game_play_screen.dart';

class LobbyScreen extends StatefulWidget {
  const LobbyScreen({Key? key}) : super(key: key);

  @override
  State<LobbyScreen> createState() => _LobbyScreenState();
}

class _LobbyScreenState extends State<LobbyScreen> {
  final TextEditingController _nameController = TextEditingController(text: 'Palace Ruler');
  final TextEditingController _roomController = TextEditingController(text: 'Royal Pavilion');
  final TextEditingController _ipController = TextEditingController(text: '192.168.43.1');

  bool _showDirectIp = false;

  @override
  void dispose() {
    _nameController.dispose();
    _roomController.dispose();
    _ipController.dispose();
    super.dispose();
  }

  void _onConnected() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const GamePlayScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final conn = Provider.of<ConnectionManager>(context);

    // If connection established, navigate to game play
    if (conn.state == ConnectionState.connected) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _onConnected());
    }

    return Scaffold(
      backgroundColor: const Color(0xFF0F0E17),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 12),
              // Palace Header & Crest
              Center(
                child: Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      colors: [Color(0xFF8B5CF6), Color(0xFFEC4899)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.pinkAccent.withOpacity(0.4),
                        blurRadius: 16,
                      ),
                    ],
                  ),
                  child: const Center(
                    child: Text('🏰', style: TextStyle(fontSize: 40)),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              const Text(
                'Palace P2P',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.2,
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                'Offline Local Multiplayer for Couples & Friends',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white60, fontSize: 13),
              ),
              const SizedBox(height: 28),

              // Player Name Field
              TextField(
                controller: _nameController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Your Character Name',
                  labelStyle: const TextStyle(color: Colors.purpleAccent),
                  prefixIcon: const Icon(Icons.person, color: Colors.purpleAccent),
                  filled: true,
                  fillColor: const Color(0xFF1F1C2E),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none,
                  ),
                ),
                onChanged: (val) => conn.setPlayerName(val),
              ),
              const SizedBox(height: 20),

              // Role Tabs: Host vs Join
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF7C3AED),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      icon: const Icon(Icons.wifi_tethering, color: Colors.white),
                      label: const Text(
                        'Host Room (Phone A)',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                      onPressed: conn.state == ConnectionState.advertising
                          ? null
                          : () {
                              conn.startHosting(roomName: _roomController.text);
                            },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFDB2777),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      icon: const Icon(Icons.search, color: Colors.white),
                      label: const Text(
                        'Join Room (Phone B)',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                      onPressed: conn.state == ConnectionState.discovering
                          ? null
                          : () {
                              conn.startDiscovering();
                            },
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 24),

              // Connection Status Card
              _buildStatusCard(conn),

              const SizedBox(height: 20),

              // Discovered Peers List
              if (conn.discoveredPeers.isNotEmpty) ...[
                const Text(
                  'Discovered Nearby Devices:',
                  style: TextStyle(color: Colors.white70, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                ...conn.discoveredPeers.map((peer) => Card(
                      color: const Color(0xFF231E3D),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      child: ListTile(
                        leading: const Icon(Icons.smartphone, color: Colors.pinkAccent),
                        title: Text(peer.endpointName, style: const TextStyle(color: Colors.white)),
                        subtitle: Text(peer.endpointId, style: const TextStyle(color: Colors.white38, fontSize: 11)),
                        trailing: ElevatedButton(
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.pinkAccent),
                          child: const Text('Connect', style: TextStyle(color: Colors.white)),
                          onPressed: () => conn.connectToPeer(peer.endpointId),
                        ),
                      ),
                    )),
              ],

              const SizedBox(height: 16),

              // Wi-Fi / Hotspot Direct IP Fallback Toggle
              TextButton.icon(
                icon: Icon(_showDirectIp ? Icons.expand_less : Icons.expand_more, color: Colors.white54),
                label: const Text(
                  'Local Wi-Fi / Hotspot Fallback (TCP Socket)',
                  style: TextStyle(color: Colors.white54, fontSize: 13),
                ),
                onPressed: () => setState(() => _showDirectIp = !_showDirectIp),
              ),

              if (_showDirectIp) ...[
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF191726),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white10),
                  ),
                  child: Column(
                    children: [
                      const Text(
                        'Connect via shared Wi-Fi or Mobile Hotspot IP:',
                        style: TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _ipController,
                        style: const TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          labelText: 'Host IP Address',
                          hintText: '192.168.43.1',
                          filled: true,
                          fillColor: const Color(0xFF28253B),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
                      const SizedBox(height: 10),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF6366F1)),
                        onPressed: () => conn.connectViaSocket(hostIp: _ipController.text),
                        child: const Text('Connect Direct IP', style: TextStyle(color: Colors.white)),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatusCard(ConnectionManager conn) {
    Color badgeColor = Colors.grey;
    String statusText = 'Offline (Tap Host or Join)';

    if (conn.state == ConnectionState.advertising) {
      badgeColor = Colors.amber;
      statusText = 'Broadcasting room (Waiting for Phone B)...';
    } else if (conn.state == ConnectionState.discovering) {
      badgeColor = Colors.cyan;
      statusText = 'Scanning for nearby rooms...';
    } else if (conn.state == ConnectionState.connecting) {
      badgeColor = Colors.orangeAccent;
      statusText = 'Establishing P2P handshake...';
    } else if (conn.state == ConnectionState.connected) {
      badgeColor = Colors.green;
      statusText = 'Connected to ${conn.remotePlayerName}!';
    }

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1728),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: badgeColor.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 12,
            height: 12,
            decoration: BoxDecoration(color: badgeColor, shape: BoxShape.circle),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              statusText,
              style: TextStyle(color: badgeColor, fontWeight: FontWeight.bold, fontSize: 13),
            ),
          ),
          if (conn.state != ConnectionState.disconnected)
            IconButton(
              icon: const Icon(Icons.refresh, color: Colors.white60, size: 20),
              onPressed: () => conn.disconnect(),
            ),
        ],
      ),
    );
  }
}
