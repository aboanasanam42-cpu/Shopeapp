# 🏰 قصر الحب والرومانسية (Palace P2P)
### لعبة ثنائية تفاعلية أوفلاين للأزواج والأحباب تعمل بدون إنترنت
**2D Local Multiplayer Palace Game for Couples & Friends with Offline P2P Synchronization**

---

## 📖 جدول المحتويات (Table of Contents)
1. [نبذة عن المشروع (Overview)](#-نبذة-عن-المشروع-overview)
2. [المميزات الرئيسية (Key Features)](#-المميزات-الرئيسية-key-features)
3. [الهيكل المعماري والتقنيات (Architecture & Tech Stack)](#-الهيكل-المعماري-والتقنيات-architecture--tech-stack)
4. [بروتوكول الشبكة ونماذج البيانات (P2P Network & Data Contracts)](#-بروتوكول-الشبكة-ونماذج-البيانات-p2p-network--data-contracts)
5. [محرك أصوات الحب والرومانسية (Romantic Audio Engine)](#-محرك-أصوات-الحب-والرومانسية-romantic-audio-engine)
6. [إعدادات وتوافق أندرويد 15 (Android 15 / SDK 35 Setup)](#-إعدادات-وتوافق-أندرويد-15-android-15--sdk-35-setup)
7. [أتمتة الرفع إلى GitHub (Automated Push Script)](#-أتمتة-الرفع-إلى-github-automated-push-script)
8. [بناء وتوقيع حزمة الـ APK عبر GitHub Actions (CI/CD Workflow)](#-بناء-وتوقيع-حزمة-الـ-apk-عبر-github-actions-cicd-workflow)
9. [دليل التشغيل السريع (Quick Start Guide)](#-دليل-التشغيل-السريع-quick-start-guide)
10. [هيكل المجلدات والملفات (Directory Structure)](#-هيكل-المجلدات-والملفات-directory-structure)

---

## 🌟 نبذة عن المشروع (Overview)
**قصر الحب والرومانسية** هي لعبة ثنائية تفاعلية ثنائية الأبعاد (2D) مصممة خصيصاً للأزواج والأحباب للعب معاً على هاتفين متجاورين دون الحاجة إلى اتصال بشبكة الإنترنت أو خوادم سحابية خارجية (Offline P2P).

يقوم الهاتف الأول بدور **المضيف (Phone A - Host)**، بينما يقوم الهاتف الثاني بدور **المنضم (Phone B - Client)** عبر تقنيات الاتصال اللاسلكي المباشر (Nearby Connections / Wi-Fi Direct / Local Hotspot / TCP Sockets).

---

## 💖 المميزات الرئيسية (Key Features)

- **🏰 بيئة القصر والحديقة الملكية المقسمة إلى 3 مناطق تفاعلية**:
  - **🌸 حديقة القصر والنافورة (Royal Garden)**: أرضية عشبية خضراء، نافورة مياه دائرية وأحواض ورد جوري.
  - **🏰 قاعة العرش والمدفأة (Grand Living Room)**: أرضيات باركيه خشبية، مدفأة مشتعلة، وسجادة مخملية حمراء.
  - **👑 جناح النوم الملكي (Royal Bedroom Suite)**: سرير ملكي ذو مظلة وشرفة تطل على سماء الليل المقمرة.

- **⚡ تزامن فائق السرعة لحركة اللاعبين (50ms Interval)**:
  - إرسال إحداثيات الحركة ($x, y$) والاتجاهات كل 50 ميلي ثانية (20Hz) مع استيفاء خطي سلس (`Linear Interpolation - Lerp`) لضمان حركة ناعمة بدون تقطيع.

- **💞 نظام استشعار الاقتراب الرومانسي (Proximity Trigger - R ≤ 50px)**:
  - حساب المسافة الإقليدية في الوقت الحقيقي: $R = \sqrt{(x_1 - x_2)^2 + (y_1 - y_2)^2}$.
  - عند اقتراب شخصيتي الهاتفين إلى مسافة 50 بكسل أو أقل داخل أي منطقة، يظهر فوراً حبل ليزري ضوئي متوهج وزر تفاعل نابض: `لحظة رومانسية 💕`.

- **💌 تفاعلات حب متبادلة متزامنة**:
  - **عناق دافئ (Warm Embrace 🤗)**: احتضان الشريك بحنان ودفء مع رنين كورال صوتي سماوي.
  - **قبلة حب رقيقة (Sweet Kiss 💋)**: لحظة رومانسية ساحرة مع صوت القبلة اللطيف وتطاير القلوب.
  - **رقصة رومانسية (Royal Waltz 💃)**: رقصة هادئة على ألحان صندوق الموسيقى الملكي.
  - **نزهة قمرية (Moonlit Stroll 🌸)**: جولة مشتركة حول نافورة الورد.

- **⏱️ مؤقت الحب المتزامن (Synchronized Timer)**:
  - إمكانية تحديد عد تنازلي مشترك (15ث، 30ث، 60ث) يظهر على كلا الشاشتين مع شريط احتفال علوي.

- **📱 وضع الرفيق الافتراضي (Solo / Companion Practice Mode)**:
  - إمكانية تجربة اللعبة والتجول في القصر والتفاعل بمفردك على هاتف واحد أو على المحاكي.

---

## 🛠️ الهيكل المعماري والتقنيات (Architecture & Tech Stack)

1. **إصدار Flutter & Flame (Cross-Platform 2D Engine)**:
   - لغة البرمجة: `Dart 3.x / Flutter 3.x`
   - محرك الألعاب: `flame: ^1.18.0`
   - إدارة الحالة: `provider: ^6.1.2`
   - بروتوكول الاتصال المحلي: `nearby_connections: ^4.1.1`

2. **إصدار Android Native (Google AI Studio Ready)**:
   - لغة البرمجة: `Kotlin 2.0+`
   - واجهة المستخدم: `Jetpack Compose & Material 3`
   - الرسم ثنائي الأبعاد: `androidx.compose.foundation.Canvas`
   - التزامن غير المتزامن: `Kotlin Coroutines & StateFlow`
   - توليد الصوت الحي: `Android AudioTrack (PCM 16-bit) + Vibrator Haptic Feedback`

---

## 📡 بروتوكول الشبكة ونماذج البيانات (P2P Network & Data Contracts)

تتم مشاركة البيانات بين الجهازين عبر حزم JSON مشفرة عبر قنوات الاتصال المحلية:

### 1. حزمة الحركة (Movement Payload) - ترسل كل 50ms:
```json
{
  "type": "MOVE",
  "x": 142.5,
  "y": 280.0,
  "dir": "right"
}
```

### 2. حزمة التفاعل واللحظات الرومانسية (Interaction Payload):
```json
{
  "type": "ACTION",
  "actionId": "HUG",
  "zone": "حديقة القصر والنافورة",
  "status": "REQUEST",
  "timerSeconds": 30
}
```
عند قبول الطرف الآخر، يتم إرسال حزمة بنفس المعرف مع `"status": "ACCEPT"` لإطلاق الأصوات وحفلة القلوب المتطايرة.

### 3. حزمة فحص الاتصال والنبض (Heartbeat Payload):
```json
{
  "type": "HEARTBEAT",
  "timestamp": 1725619200000
}
```

---

## 🎵 محرك أصوات الحب والرومانسية (Romantic Audio Engine)

تم تضمين فئة `RomanticSoundManager` التي تقوم بتوليد موجات صوتية حية (Pure Synthesized Audio Waves) بدقة 44.1kHz دون الحاجة إلى تنزيل ملفات mp3 من الإنترنت:

- **💓 خفقان القلب الطبيعي (`playHeartbeat`)**:
  - توليد موجة جيبية مزدوجة تحاكي نبضات القلب (55Hz و 75Hz) مصحوبة باهتزاز لمسي هادئ في الهاتف.
- **💋 صوت القبلة اللطيف (`playKissSound`)**:
  - تردد صاعد ناعم من 1400Hz إلى 2600Hz مع انخفاض أسي مغلف.
- **🤗 نغمة العناق الدافئ (`playWarmHugSound`)**:
  - نغمات كورد هارمونية متوافقة (C5, E5, G5, C6).
- **💃 ألحان الرقصة الرومانسية (`playRomanticWaltz`)**:
  - أربيجيو موسيقي حالِم يحاكي صوت آلة الهارب وصندوق الموسيقى (D5, F#5, A5, D6, F#6).
- **✨ رنين الاقتراب التلقائي (`playProximityChime`)**:
  - رنين تنبيهي لطيف يعزف تلقائياً عند دخول دائرة الـ 50 بكسل.

---

## 📱 إعدادات وتوافق أندرويد 15 (Android 15 / SDK 35 Setup)

تم ضبط ملف `app/src/main/AndroidManifest.xml` بالصلاحيات الدقيقة الحديثة:
```xml
<!-- أذونات البلوتوث لأجهزة أندرويد 12 فما فوق (API 31+) -->
<uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation" />
<uses-permission android:name="android.permission.BLUETOOTH_ADVERTISE" />
<uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />

<!-- أذونات الواي فاي المباشر لأجهزة أندرويد 13 وأندرويد 15 (API 33-35) -->
<uses-permission android:name="android.permission.NEARBY_WIFI_DEVICES" android:usesPermissionFlags="neverForLocation" />
<uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
<uses-permission android:name="android.permission.CHANGE_WIFI_STATE" />
<uses-permission android:name="android.permission.CHANGE_WIFI_MULTICAST_STATE" />
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.VIBRATE" />
```

---

## 🚀 أتمتة الرفع إلى GitHub (Automated Push Script)

تم إنشاء ملف `setup_and_push.sh` الجاهز للتنفيذ والذي يقوم بالآتي:
1. التحقق من تثبيت `git`.
2. تهيئة المستودع المحلي (`git init`).
3. إعداد ملف `.gitignore` لحماية المفاتيح ومنع رفع مخلفات البناء.
4. تجهيز الـ Commit الأول بكافة الملفات.
5. الربط التلقائي بالمستودع الخاص بك: `https://github.com/aboanasanam42-cpu/wife.git`.
6. الرفع الفوري لفرع `main`.

### أمر التشغيل في الطرفية (Terminal):
```bash
chmod +x setup_and_push.sh
./setup_and_push.sh
```

---

## ⚙️ بناء وتوقيع حزمة الـ APK عبر GitHub Actions (CI/CD Workflow)

تم إعداد ملف العمل `.github/workflows/build_apk.yml` بحيث يتكامل مباشرة مع الرموز السرية (Secrets) التي قمت بتهيئتها في مستودعك:

| اسم المتغير السري (Secret Name) | الغرض والاستخدام في البناء الآلي |
|:---|:---|
| `KEYSTORE_BASE64` | كود Base64 لمفتاح التوقيع الرقمي، يُفك تشفيره لإنتاج ملف `release.keystore` |
| `CM_KEYSTORE_PASSWORD` | كلمة سر مخزن المفاتيح (Keystore Password) |
| `CM_KEY_ALIAS` | الاسم المستعار للمفتاح (Key Alias) |
| `CM_KEY_PASSWORD` | كلمة سر المفتاح الفردي (Key Password) |
| `GEMINI_API_KEY` | مفتاح Gemini API يُحقن في ملف `.env` الداخلي |

### كيف يتم الحصول على ملف الـ APK؟
1. فور تنفيذ `./setup_and_push.sh` ورفع التعديلات، سيبدأ الـ Workflow بالعمل تلقائياً تحت تبويب **Actions** في صفحة مستودعك.
2. عند اكتمال البناء الأخضر، ستجد ملف الـ APK موقعاً وجاهزاً للتحميل تحت قسم **Artifacts** باسم:
   `Palace-Love-Android15-Release-APK`
3. قم بتحميل الملف وتثبيته مباشرة على الهاتفين.

---

## 🎮 دليل التشغيل السريع (Quick Start Guide)

### الاتصال بين جهازين (Two Devices):
1. **الجهاز الأول (الهاتف أ - المضيف)**:
   - افتح التطبيق، واكتب اسم شخصيتك (مثال: `أمير القصر`).
   - اضغط على زر **"إنشاء غرفة القصر (الهاتف أ - المضيف)"**.
   - سيظهر عنوان الـ IP المحلي في الشريط العلوي (مثال: `192.168.43.1`).
2. **الجهاز الثاني (الهاتف ب - المنضم)**:
   - افتح التطبيق، واكتب اسم شخصيتك (مثال: `أميرة القصر`).
   - اكتب عنوان IP الهاتف أ في حقل الاتصال.
   - اضغط على زر **"اتصال بالهاتف أ والبدء 💕"**.
3. **بدء اللعب والتفاعل**:
   - تحكم في حركتك داخل القصر عبر عصا التحكم الافتراضية (Virtual Joystick).
   - اقترب من شريكك حتى مسافة الـ 50 بكسل لتفعيل الرنين التلقائي وشعاع الحب.
   - اضغط على زر **"لحظة رومانسية 💕"** لاختيار عناق أو قبلة أو رقصة مع تحديد المؤقت التنازلي!

---

## 📂 هيكل المجلدات والملفات (Directory Structure)

```text
├── .github/
│   └── workflows/
│       └── build_apk.yml            # إعدادات البناء الآلي وتوقيع APK عبر GitHub Actions
├── app/
│   └── src/main/
│       ├── AndroidManifest.xml      # أذونات أندرويد 15 والبلوتوث والواي فاي
│       ├── java/com/example/
│       │   ├── MainActivity.kt      # نقطة انطلاق واجهات Jetpack Compose
│       │   ├── audio/
│       │   │   └── RomanticSoundManager.kt # محرك أصوات الحب ونبضات القلب والاهتزاز
│       │   ├── game/
│       │   │   └── PalaceGameEngine.kt     # محرك القصر، المناطق، ونظام استشعار الاقتراب
│       │   ├── model/
│       │   │   └── PacketModel.kt          # كائنات وبيانات التزامن (Move/Action/Heartbeat)
│       │   ├── network/
│       │   │   └── LocalP2PManager.kt      # خادم وعميل السوكت P2P الأوفلاين
│       │   └── ui/
│       │       ├── components/
│       │       │   ├── GameCanvas.kt       # رسم القصر والحديقة والأشخاص والقلوب
│       │       │   └── VirtualJoystick.kt  # عصا التحكم الافتراضية اللمسية
│       │       └── screens/
│       │           ├── LobbyScreen.kt      # شاشة الاستقبال وتحديد الاسم والاتصال
│       │           ├── GameScreen.kt       # شاشة اللعب والواجهة التفاعلية والمؤقت
│       │           └── PushGuideScreen.kt  # شاشة دليل الرفع والبناء
│       └── res/
│           ├── values/strings.xml           # موارد النصوص باللغة الإنجليزية
│           └── values-ar/strings.xml        # موارد النصوص باللغة العربية
├── lib/
│   ├── main.dart                    # نقطة انطلاق كود Flutter
│   ├── game/
│   │   ├── palace_game.dart         # محرك لعبة Flame 2D
│   │   ├── components/              # كائنات ورسومات اللاعبين والمناطق في Flutter
│   │   └── overlays/                # حوار التفاعل وعصا التحكم اللمسية
│   ├── network/                     # إدارة الاتصال المحلي بحزم Dart
│   └── screens/                     # شاشات اللوبي واللعب في Flutter
├── pubspec.yaml                     # إعدادات واعتماديات فلاتر ومحرك فليم
├── setup_and_push.sh                # سكريبت الأتمتة والرفع المباشر إلى GitHub
├── metadata.json                    # بيانات وهوية التطبيق في منصة Google AI Studio
└── README.md                        # التوثيق الشامل الكامل للمشروع
```

---

### صُنع بكل حب 💖 ليكون تجربة ثنائية مميزة تجمع القلوب أينما كانت.
