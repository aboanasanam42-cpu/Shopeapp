package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.TextToSpeechManager
import com.example.data.LibraryRepository
import com.example.model.ArticleItem
import com.example.model.ArticleType
import com.example.ui.components.AudioSpeakerButton
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArticlesScreen(
    repository: LibraryRepository,
    ttsManager: TextToSpeechManager,
    onArticleClick: (String) -> Unit,
    onBack: () -> Unit
) {
    val articles by repository.articles.collectAsState()
    var selectedType by remember { mutableStateOf<ArticleType?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }

    val filteredArticles = remember(articles, selectedType, searchQuery) {
        articles.filter { item ->
            val matchesType = selectedType == null || item.type == selectedType
            val matchesQuery = searchQuery.isBlank() ||
                    item.title.contains(searchQuery, ignoreCase = true) ||
                    item.content.contains(searchQuery, ignoreCase = true) ||
                    item.description.contains(searchQuery, ignoreCase = true)
            matchesType && matchesQuery
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "المقالات والروايات والخطب والشعر",
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("articles_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع", tint = GoldPrimary)
                    }
                },
                actions = {
                    IconButton(onClick = { showAddDialog = true }, modifier = Modifier.testTag("add_new_article_btn")) {
                        Icon(Icons.Default.AddCircleOutline, contentDescription = "إضافة عمل أدبي", tint = TealAccent)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 14.dp)
        ) {
            // Search field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .testTag("articles_search_input"),
                placeholder = { Text("ابحث في المقالات والروايات والشعر...", color = TextMuted, fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TealAccent) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "مسح", tint = TextMuted)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TealAccent,
                    unfocusedBorderColor = GlassBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface
                )
            )

            // Category Chips: All, Novel, Article, Speech, Poetry
            val typeTabs = listOf(
                "الكل" to null,
                "رواية" to ArticleType.NOVEL,
                "مقالات" to ArticleType.ARTICLE,
                "خطب ومحاضرات" to ArticleType.SPEECH,
                "ديوان الشعر" to ArticleType.POETRY
            )

            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(typeTabs) { (title, type) ->
                    val isSelected = selectedType == type
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedType = type },
                        label = { Text(title, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = TealAccent,
                            selectedLabelColor = DarkBackground,
                            containerColor = DarkSurface,
                            labelColor = TextSecondary
                        ),
                        border = BorderStroke(1.dp, if (isSelected) TealAccent else GlassBorder.copy(alpha = 0.5f))
                    )
                }
            }

            // Articles List
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(filteredArticles, key = { it.id }) { item ->
                    ArticleListItemCard(
                        item = item,
                        ttsManager = ttsManager,
                        onClick = { onArticleClick(item.id) }
                    )
                }
            }
        }
    }

    if (showAddDialog) {
        AddNewArticleDialog(
            onDismiss = { showAddDialog = false },
            onAdd = { newItem ->
                repository.addNewArticle(newItem)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun ArticleListItemCard(
    item: ArticleItem,
    ttsManager: TextToSpeechManager,
    onClick: () -> Unit
) {
    val typeName = when (item.type) {
        ArticleType.NOVEL -> "رواية"
        ArticleType.ARTICLE -> "مقالة"
        ArticleType.SPEECH -> "خطبة / موعظة"
        ArticleType.POETRY -> "قصيدة / شعر"
    }

    val typeColor = when (item.type) {
        ArticleType.NOVEL -> CoralRed
        ArticleType.ARTICLE -> CyanAccent
        ArticleType.SPEECH -> GoldAccent
        ArticleType.POETRY -> TealAccent
    }

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("article_card_${item.id}"),
        borderGlowColor = typeColor,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Badge(containerColor = typeColor.copy(alpha = 0.2f)) {
                Text(
                    text = typeName,
                    color = typeColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }

            if (item.date.isNotBlank()) {
                Text(text = item.date, color = TextMuted, fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = item.title,
            color = GoldLight,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = item.description.ifBlank { item.content.take(120) },
            color = TextSecondary,
            fontSize = 12.sp,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
            lineHeight = 17.sp
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Actions: TTS voice speaker button + Read action
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            AudioSpeakerButton(
                textToRead = "${item.title}. ${item.content}",
                ttsManager = ttsManager,
                label = "استماع صوتي"
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "قراءة كامل النص", color = TealAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(4.dp))
                Icon(Icons.AutoMirrored.Filled.ArrowForwardIos, contentDescription = null, tint = TealAccent, modifier = Modifier.size(12.dp))
            }
        }
    }
}

@Composable
fun AddNewArticleDialog(
    onDismiss: () -> Unit,
    onAdd: (ArticleItem) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(ArticleType.ARTICLE) }
    var description by remember { mutableStateOf("") }
    var contentText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة عمل أدبي جديد", color = GoldLight, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان المقالة / الرواية / القصيدة") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        "مقالة" to ArticleType.ARTICLE,
                        "رواية" to ArticleType.NOVEL,
                        "خطبة" to ArticleType.SPEECH,
                        "شعر" to ArticleType.POETRY
                    ).forEach { (lbl, t) ->
                        FilterChip(
                            selected = selectedType == t,
                            onClick = { selectedType = t },
                            label = { Text(lbl, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("نبذة مختصرة") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = contentText,
                    onValueChange = { contentText = it },
                    label = { Text("النص والقصيدة الكاملة") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp),
                    maxLines = 10
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val newItem = ArticleItem(
                            id = "custom_art_${System.currentTimeMillis()}",
                            title = title.trim(),
                            type = selectedType,
                            date = "جديد",
                            author = "الدكتور مالك عبدالرحمن الرميمة",
                            summary = description.ifBlank { "عمل مضاف حديثاً" },
                            content = contentText.ifBlank { "لم تتم إضافة نصوص إضافية." },
                            isCustom = true
                        )
                        onAdd(newItem)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
            ) {
                Text("حفظ وإضافة", color = DarkBackground, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء", color = TextMuted) }
        },
        containerColor = DarkSurface
    )
}
