package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.TextToSpeechManager
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.GlassHighlight
import com.example.ui.theme.GlassSurface
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldPrimary

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 18.dp,
    borderGlowColor: Color = GoldPrimary,
    borderColor: Color = borderGlowColor,
    backgroundColor: Color = GlassSurface,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)
    val clickModifier = if (onClick != null) Modifier.clickable { onClick() } else Modifier
    val effectiveBorderColor = if (borderColor != borderGlowColor) borderColor else borderGlowColor

    Box(
        modifier = modifier
            .shadow(elevation = 10.dp, shape = shape, spotColor = effectiveBorderColor.copy(alpha = 0.35f))
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    listOf(
                        backgroundColor.copy(alpha = 0.95f),
                        backgroundColor.copy(alpha = 0.85f)
                    )
                )
            )
            .border(
                BorderStroke(
                    width = 1.5.dp,
                    brush = Brush.linearGradient(
                        listOf(
                            effectiveBorderColor.copy(alpha = 0.85f),
                            GlassHighlight.copy(alpha = 0.3f),
                            effectiveBorderColor.copy(alpha = 0.6f)
                        )
                    )
                ),
                shape = shape
            )
            .then(clickModifier)
            .padding(12.dp)
    ) {
        Column {
            content()
        }
    }
}

@Composable
fun GlowingBorderCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 18.dp,
    glowColors: List<Color> = listOf(GoldPrimary, Color(0xFF00E5FF)),
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "glow")
    val borderAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    val shape = RoundedCornerShape(cornerRadius)
    val clickModifier = if (onClick != null) Modifier.clickable { onClick() } else Modifier

    Box(
        modifier = modifier
            .shadow(elevation = 12.dp, shape = shape, spotColor = glowColors.firstOrNull() ?: GoldPrimary)
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xF0121B2B),
                        Color(0xF00A111E)
                    )
                )
            )
            .border(
                width = 1.8.dp,
                brush = Brush.linearGradient(
                    glowColors.map { it.copy(alpha = borderAlpha) }
                ),
                shape = shape
            )
            .then(clickModifier)
            .padding(12.dp)
    ) {
        Column {
            content()
        }
    }
}

@Composable
fun AudioSpeakerButton(
    ttsManager: TextToSpeechManager,
    textToRead: String = "",
    textToSpeak: String = textToRead,
    modifier: Modifier = Modifier,
    utteranceId: String = "speaker_tag",
    label: String = "استماع صوتي",
    tint: Color = GoldPrimary
) {
    val resolvedText = if (textToSpeak.isNotBlank()) textToSpeak else textToRead
    val isSpeaking by ttsManager.isSpeaking.collectAsState()
    val currentText by ttsManager.currentText.collectAsState()
    val isCurrentAudio = isSpeaking && currentText == resolvedText

    if (label.isBlank() || label == "icon_only") {
        IconButton(
            onClick = {
                if (isCurrentAudio) {
                    ttsManager.stop()
                } else {
                    ttsManager.speak(resolvedText, utteranceId)
                }
            },
            modifier = modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(tint.copy(alpha = 0.15f))
        ) {
            Icon(
                imageVector = if (isCurrentAudio) Icons.Default.Stop else Icons.AutoMirrored.Filled.VolumeUp,
                contentDescription = if (isCurrentAudio) "إيقاف الصوت" else "استماع صوتي",
                tint = tint,
                modifier = Modifier.size(20.dp)
            )
        }
    } else {
        ElevatedButton(
            onClick = {
                if (isCurrentAudio) {
                    ttsManager.stop()
                } else {
                    ttsManager.speak(resolvedText, utteranceId)
                }
            },
            colors = ButtonDefaults.elevatedButtonColors(
                containerColor = if (isCurrentAudio) Color(0xFFEF4444) else GoldPrimary,
                contentColor = if (isCurrentAudio) Color.White else DarkBackground
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = modifier
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = if (isCurrentAudio) Icons.Default.Stop else Icons.AutoMirrored.Filled.VolumeUp,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isCurrentAudio) "إيقاف الاستماع" else label,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
