package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.audio.TextToSpeechManager
import com.example.data.LibraryRepository
import com.example.ui.components.AudioSpeakerButton
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DoctorBioScreen(
    repository: LibraryRepository,
    ttsManager: TextToSpeechManager,
    onBack: () -> Unit
) {
    val fullBioText = remember {
        """
        السيرة الذاتية للدكتور مالك عبدالرحمن عبد الولي الرميمة:
        طبيب جراحة الفم والأسنان، باحث ومؤلف في العلوم الإسلامية والطبية والتربوية، وشاعر.
        
        البيانات الشخصية:
        - الاسم: مالك عبد الرحمن عبد الولي الرميمة
        - الجنسية: يمني
        - العمر: 34 سنة، الحالة الاجتماعية: متزوج.
        - اللغات: العربية (اللغة الأم)، والإنجليزية (بامتياز - لغة الدراسة الطبية).
        
        المؤهلات العلمية:
        - بكالوريوس في طب وجراحة الفم والأسنان بتقدير جيد من كلية طب الأسنان - جامعة ذمار (2011-2012م).
        - دبلوم الرخصة الدولية لقيادة الحاسوب (ICDL) بتقدير عام ممتاز (2023م).
        - شهادات المؤتمر الدولي لتبادل طب الأسنان (IDEC 2024 و IDEC 2025) بواقع 100 ساعة معتمدة.
        - مؤتمر روجين الدولي المتقدم في علاج جذور الأسنان.
        - المشاركة في المؤتمرات العلمية لنقابة أطباء الأسنان بتعز وصنعاء.
        
        الخبرات المهنية والأكاديمية:
        - التدريس الأكاديمي في: جامعة تعز، جامعة السعيد، الجامعة الوطنية، جامعة الحكمة، وجامعة العطاء (2014-2020م).
        - رئيس قسم الأسنان بمستشفى المظفر الحكومي بمدينة تعز (2014-2016م).
        - رئيس قسم الأسنان بمركز الناصر الطبي جولة المرور (2014-2019م).
        - العمل في عيادة الرحمن التخصصية منذ 2019م وحتى الآن.
        
        الإنتاج الفكري والمؤلفات:
        مؤلف 17 كتاباً بارزاً تشمل: كتاب عمل القلوب، مبطلات الطب، أثر الفكر الغربي المعاصر، إلى المفازة العظمى، طبيبك المنزلي، ابدأ من الصفر، استكفي مما تزرع، آيات قرآنية في الأرزاق الربانية، جند الله في السماوات والأرض، دع السقم، سباعية النشأة، ظلم الشعوب المسلمة تحت شعار الوطنية، عمى القلوب، وللشعر حلاوة كحلاوة السكر، مزامير من حكم، نفحات من آية الكرسي، نواميس في محراب الرحمن، ورواية حديقة السلام.
        
        للتواصل: هاتف وواتساب: 771134103.
        """.trimIndent()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "السيرة الذاتية للدكتور مالك الرميمة",
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("bio_back_button")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = GoldPrimary
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { repository.callDoctor() }) {
                        Icon(Icons.Default.Phone, contentDescription = "اتصال", tint = GoldAccent)
                    }
                    IconButton(onClick = { repository.openWhatsApp() }) {
                        Icon(Icons.Default.Chat, contentDescription = "واتساب", tint = EmeraldGreen)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Profile Card with Photo
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                borderGlowColor = GoldAccent
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .border(2.dp, GoldPrimary, CircleShape)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.dr_malek_photo),
                            contentDescription = "صورة الدكتور مالك عبدالرحمن الرميمة",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Text(
                            text = "الدكتور مالك عبدالرحمن الرميمة",
                            color = GoldLight,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "طبيب جراحة الفم والأسنان • باحث ومؤلف وشاعر",
                            color = TealAccent,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Phone, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "771134103", color = TextSecondary, fontSize = 13.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Voice reading button
                AudioSpeakerButton(
                    textToRead = fullBioText,
                    ttsManager = ttsManager,
                    modifier = Modifier.fillMaxWidth(),
                    label = "المتكلم الصوتي (استماع للسيرة الذاتية)"
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Bio Details Sections
            BioSectionCard(
                title = "البيانات الشخصية واللغات",
                icon = Icons.Default.Person,
                iconTint = CyanAccent
            ) {
                BioItem("الاسم الكامل", "مالك عبد الرحمن عبد الولي الرميمة")
                BioItem("الجنسية", "يمني (اليمن)")
                BioItem("العمر", "34 سنة")
                BioItem("الحالة الاجتماعية", "متزوج")
                BioItem("اللغات", "العربية (الأم) • الإنجليزية (جيد جداً)")
            }

            Spacer(modifier = Modifier.height(12.dp))

            BioSectionCard(
                title = "المؤهلات العلمية والتخصصية",
                icon = Icons.Default.School,
                iconTint = GoldAccent
            ) {
                BioItem("المؤهل الجامعي", "بكالوريوس في طب وجراحة الفم والأسنان - جامعة ذمار (2011-2012م)")
                BioItem("الثانوية العامة", "القسم العلمي بتقدير جيد جداً (2005-2006م)")
                BioItem("شهادة الحاسوب", "دبلوم الرخصة الدولية لقيادة الحاسوب (ICDL) بامتياز (2023م)")
            }

            Spacer(modifier = Modifier.height(12.dp))

            BioSectionCard(
                title = "المؤتمرات الدولية والتعليم المستمر",
                icon = Icons.Default.WorkspacePremium,
                iconTint = EmeraldGreen
            ) {
                BioItem("مؤتمر IDEC 2024", "100 ساعة معتمدة من المؤتمر الدولي لتبادل طب الأسنان")
                BioItem("مؤتمر IDEC 2025", "100 ساعة معتمدة من المؤتمر الدولي لتبادل طب الأسنان")
                BioItem("مؤتمر روجين Rogin", "سلسلة متقدمة في علاج جذور الأسنان وتطوير المهارات التخصصية")
                BioItem("مؤتمرات نقابة الأسنان", "المؤتمرات العلمية لنقابة أطباء الأسنان في تعز وصنعاء")
            }

            Spacer(modifier = Modifier.height(12.dp))

            BioSectionCard(
                title = "الخبرات العملية والأكاديمية",
                icon = Icons.Default.MedicalServices,
                iconTint = TealAccent
            ) {
                BioItem("التدريس الجامعي", "جامعة تعز، السعيد، الوطنية، الحكمة، العطاء (2014 - 2020م)")
                BioItem("مستشفى المظفر الحكومي", "رئيس قسم الأسنان بمستشفى المظفر بمدينة تعز (2014 - 2016م)")
                BioItem("مركز الناصر الطبي", "رئيس قسم الأسنان بالفترة المسائية (2014 - 2019م)")
                BioItem("عيادة الرحمن", "العمل السريري المستمر من 2019م وحتى الآن")
            }

            Spacer(modifier = Modifier.height(12.dp))

            BioSectionCard(
                title = "الإنتاج الفكري والأدبي (17 كتاباً)",
                icon = Icons.Default.MenuBook,
                iconTint = GoldLight
            ) {
                Text(
                    text = "مؤلف 17 كتاباً ورسالة تشمل: كتاب عمل القلوب، مبطلات الطب، أثر الفكر الغربي المعاصر، إلى المفازة العظمى، طبيبك المنزلي، ابدأ من الصفر، استكفي مما تزرع، آيات قرآنية في الأرزاق الربانية، جند الله في السماوات والأرض، دع السقم، سباعية النشأة، ظلم الشعوب المسلمة تحت شعار الوطنية، عمى القلوب، وللشعر حلاوة كحلاوة السكر، مزامير من حكم، نفحات من آية الكرسي، نواميس في محراب الرحمن، ورواية حديقة السلام.",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 20.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Contact Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { repository.callDoctor() },
                    modifier = Modifier.weight(1f).testTag("bio_call_action"),
                    colors = ButtonDefaults.buttonColors(containerColor = GoldDark)
                ) {
                    Icon(Icons.Default.Phone, contentDescription = null, tint = GoldLight)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("اتصال هاتفي", color = Color.White)
                }

                Button(
                    onClick = { repository.openWhatsApp() },
                    modifier = Modifier.weight(1f).testTag("bio_whatsapp_action"),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen)
                ) {
                    Icon(Icons.Default.Chat, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("واتساب", color = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun BioSectionCard(
    title: String,
    icon: ImageVector,
    iconTint: Color,
    content: @Composable ColumnScope.() -> Unit
) {
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        borderGlowColor = iconTint
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 8.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = title,
                color = GoldLight,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
        HorizontalDivider(color = GlassBorder.copy(alpha = 0.4f), thickness = 0.8.dp)
        Spacer(modifier = Modifier.height(8.dp))
        content()
    }
}

@Composable
private fun BioItem(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = TextMuted, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Normal,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(1f, fill = false)
        )
    }
}
