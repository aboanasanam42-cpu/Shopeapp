package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ai.GeminiAssistantService
import com.example.audio.TextToSpeechManager
import com.example.data.LibraryRepository
import com.example.ui.screens.*
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private lateinit var ttsManager: TextToSpeechManager
    private lateinit var libraryRepository: LibraryRepository
    private lateinit var geminiService: GeminiAssistantService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        ttsManager = TextToSpeechManager(applicationContext)
        libraryRepository = LibraryRepository(applicationContext)
        geminiService = GeminiAssistantService()

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DarkBackground
                ) {
                    val navController = rememberNavController()

                    NavHost(
                        navController = navController,
                        startDestination = "home"
                    ) {
                        // 1. Home Dashboard
                        composable("home") {
                            HomeScreen(
                                repository = libraryRepository,
                                ttsManager = ttsManager,
                                onNavigateToBio = { navController.navigate("bio") },
                                onNavigateToBooks = { navController.navigate("books") },
                                onNavigateToArticles = { navController.navigate("articles") },
                                onNavigateToGemini = { navController.navigate("gemini") },
                                onNavigateToSearch = { navController.navigate("search") }
                            )
                        }

                        // 2. Doctor Biography & CV
                        composable("bio") {
                            DoctorBioScreen(
                                repository = libraryRepository,
                                ttsManager = ttsManager,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        // 3. Books & Publications Catalog
                        composable("books") {
                            BooksScreen(
                                repository = libraryRepository,
                                ttsManager = ttsManager,
                                onBookClick = { bookId ->
                                    navController.navigate("book_reader/$bookId/1")
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        // 4. Book Reader
                        composable(
                            route = "book_reader/{bookId}/{page}",
                            arguments = listOf(
                                navArgument("bookId") { type = NavType.StringType },
                                navArgument("page") { type = NavType.IntType; defaultValue = 1 }
                            )
                        ) { backStackEntry ->
                            val bookId = backStackEntry.arguments?.getString("bookId") ?: ""
                            val page = backStackEntry.arguments?.getInt("page") ?: 1
                            BookReaderScreen(
                                bookId = bookId,
                                initialPage = page,
                                repository = libraryRepository,
                                ttsManager = ttsManager,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        // 5. Articles, Novels, Speeches, Poetry
                        composable("articles") {
                            ArticlesScreen(
                                repository = libraryRepository,
                                ttsManager = ttsManager,
                                onArticleClick = { articleId ->
                                    navController.navigate("article_reader/$articleId")
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        // 6. Article / Novel Reader
                        composable(
                            route = "article_reader/{articleId}",
                            arguments = listOf(
                                navArgument("articleId") { type = NavType.StringType }
                            )
                        ) { backStackEntry ->
                            val articleId = backStackEntry.arguments?.getString("articleId") ?: ""
                            ArticleReaderScreen(
                                articleId = articleId,
                                repository = libraryRepository,
                                ttsManager = ttsManager,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        // 7. Gemini 3.6 Flash Assistant
                        composable("gemini") {
                            GeminiChatScreen(
                                geminiService = geminiService,
                                ttsManager = ttsManager,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        // 8. Universal Library Search
                        composable("search") {
                            LibrarySearchScreen(
                                repository = libraryRepository,
                                ttsManager = ttsManager,
                                onNavigateToBook = { bookId, page ->
                                    navController.navigate("book_reader/$bookId/$page")
                                },
                                onNavigateToArticle = { articleId ->
                                    navController.navigate("article_reader/$articleId")
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        ttsManager.shutdown()
    }
}
