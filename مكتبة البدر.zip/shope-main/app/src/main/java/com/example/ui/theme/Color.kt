package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GoldPrimary = Color(0xFFD4AF37)
val GoldLight = Color(0xFFF3E5AB)
val GoldDark = Color(0xFFAA820A)
val GoldAccent = Color(0xFFFFD700)
val GoldGlow = Color(0x66FFD700)
val GoldBorder = Color(0x66D4AF37)

val DarkBackground = Color(0xFF090E17)
val DarkSurface = Color(0xFF131D2E)
val GlassSurface = Color(0xDD111F30)
val GlassBorder = Color(0x66D4AF37)
val GlassHighlight = Color(0x33FFFFFF)

val CyanAccent = Color(0xFF00E5FF)
val TealAccent = Color(0xFF00B4D8)
val EmeraldGreen = Color(0xFF10B981)
val CoralRed = Color(0xFFEF4444)

val NeonPurple = Color(0xFFB026FF)
val NeonCyan = Color(0xFF00E5FF)
val NeonBlue = Color(0xFF38BDF8)
val NeonPink = Color(0xFFEC4899)

val TextGold = Color(0xFFFFE082)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFFCBD5E1)
val TextMuted = Color(0xFF94A3B8)
