package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.TextToSpeechManager
import com.example.data.LibraryRepository
import com.example.model.ArticleItem
import com.example.model.ArticleType
import com.example.ui.components.AudioSpeakerButton
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArticleReaderScreen(
    articleId: String,
    repository: LibraryRepository,
    ttsManager: TextToSpeechManager,
    onBack: () -> Unit
) {
    val article: ArticleItem? = remember(articleId) { repository.getArticleById(articleId) }

    if (article == null) {
        Box(
            modifier = Modifier.fillMaxSize().background(DarkBackground),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("عذراً، لم يتم العثور على المحتوى المطلوب", color = TextSecondary)
                Spacer(modifier = Modifier.height(12.dp))
                Button(onClick = onBack) { Text("العودة") }
            }
        }
        return
    }

    var fontSize by remember { mutableStateOf(16.sp) }
    val fullTextToRead = "${article.title}. ${article.content}"

    val typeName = when (article.type) {
        ArticleType.NOVEL -> "رواية"
        ArticleType.ARTICLE -> "مقالة"
        ArticleType.SPEECH -> "خطبة / موعظة"
        ArticleType.POETRY -> "ديوان الشعر"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = article.title,
                            color = GoldLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            maxLines = 1
                        )
                        Text(
                            text = "$typeName • د. مالك الرميمة",
                            color = TealAccent,
                            fontSize = 11.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("article_reader_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع", tint = GoldPrimary)
                    }
                },
                actions = {
                    IconButton(onClick = { if (fontSize.value > 12) fontSize = (fontSize.value - 2).sp }) {
                        Text("A-", color = GoldLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    IconButton(onClick = { if (fontSize.value < 26) fontSize = (fontSize.value + 2).sp }) {
                        Text("A+", color = GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        },
        bottomBar = {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = DarkSurface,
                border = BorderStroke(1.dp, GlassBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "الاستماع الصوتي للنص كاملاً:",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )

                    AudioSpeakerButton(
                        textToRead = fullTextToRead,
                        ttsManager = ttsManager,
                        utteranceId = "article_${article.id}",
                        label = "استماع صوتي كامل"
                    )
                }
            }
        },
        containerColor = DarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(14.dp)
        ) {
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                borderGlowColor = TealAccent
            ) {
                Text(
                    text = article.title,
                    color = GoldAccent,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                if (article.description.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = article.description,
                        color = TealAccent,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = GlassBorder.copy(alpha = 0.5f), thickness = 1.dp)
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = article.content,
                    color = TextPrimary,
                    fontSize = fontSize,
                    lineHeight = (fontSize.value * 1.7f).sp,
                    textAlign = if (article.type == ArticleType.POETRY) TextAlign.Center else TextAlign.Justify,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
