package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.TextToSpeechManager
import com.example.data.LibraryRepository
import com.example.model.Book
import com.example.ui.components.AudioSpeakerButton
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookReaderScreen(
    bookId: String,
    initialPage: Int = 1,
    repository: LibraryRepository,
    ttsManager: TextToSpeechManager,
    onBack: () -> Unit
) {
    val book: Book? = remember(bookId) { repository.getBookById(bookId) }

    if (book == null) {
        Box(
            modifier = Modifier.fillMaxSize().background(DarkBackground),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("عذراً، لم يتم العثور على هذا الكتاب", color = TextSecondary)
                Spacer(modifier = Modifier.height(12.dp))
                Button(onClick = onBack) { Text("العودة للمكتبة") }
            }
        }
        return
    }

    val totalPages = book.pages.size
    var currentPageIndex by remember { mutableStateOf((initialPage - 1).coerceIn(0, (totalPages - 1).coerceAtLeast(0))) }
    var fontSize by remember { mutableStateOf(16.sp) }
    val currentPage = book.pages.getOrNull(currentPageIndex)

    val pageContentToRead = remember(currentPage, book) {
        val title = currentPage?.title ?: book.title
        val content = currentPage?.content ?: book.description
        "$title. $content"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = book.title,
                            color = GoldLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            maxLines = 1
                        )
                        Text(
                            text = "صفحة ${currentPageIndex + 1} من $totalPages",
                            color = TealAccent,
                            fontSize = 11.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("reader_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع", tint = GoldPrimary)
                    }
                },
                actions = {
                    // Font Size controls
                    IconButton(onClick = { if (fontSize.value > 12) fontSize = (fontSize.value - 2).sp }) {
                        Text("A-", color = GoldLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    IconButton(onClick = { if (fontSize.value < 26) fontSize = (fontSize.value + 2).sp }) {
                        Text("A+", color = GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        },
        bottomBar = {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = DarkSurface,
                border = BorderStroke(1.dp, GlassBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Previous Page
                    Button(
                        onClick = { if (currentPageIndex > 0) currentPageIndex-- },
                        enabled = currentPageIndex > 0,
                        colors = ButtonDefaults.buttonColors(containerColor = GoldDark),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("السابق", color = Color.White, fontSize = 12.sp)
                    }

                    // Automatic Audio Voice Reader
                    AudioSpeakerButton(
                        textToRead = pageContentToRead,
                        ttsManager = ttsManager,
                        utteranceId = "book_${book.id}_page_${currentPageIndex + 1}",
                        label = "المتكلم الصوتي"
                    )

                    // Next Page
                    Button(
                        onClick = { if (currentPageIndex < totalPages - 1) currentPageIndex++ },
                        enabled = currentPageIndex < totalPages - 1,
                        colors = ButtonDefaults.buttonColors(containerColor = GoldDark),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("التالي", color = Color.White, fontSize = 12.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = Color.White)
                    }
                }
            }
        },
        containerColor = DarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(14.dp)
        ) {
            if (currentPage != null) {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderGlowColor = GoldPrimary
                ) {
                    if (currentPage.title.isNotBlank()) {
                        Text(
                            text = currentPage.title,
                            color = GoldAccent,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                        )
                        HorizontalDivider(color = GlassBorder.copy(alpha = 0.5f), thickness = 1.dp)
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    Text(
                        text = currentPage.content,
                        color = TextPrimary,
                        fontSize = fontSize,
                        lineHeight = (fontSize.value * 1.6f).sp,
                        textAlign = TextAlign.Justify,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
