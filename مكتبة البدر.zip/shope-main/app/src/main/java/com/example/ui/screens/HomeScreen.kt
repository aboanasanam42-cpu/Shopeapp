package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.audio.TextToSpeechManager
import com.example.data.LibraryRepository
import com.example.ui.components.AudioSpeakerButton
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    repository: LibraryRepository,
    ttsManager: TextToSpeechManager,
    onNavigateToBio: () -> Unit,
    onNavigateToBooks: () -> Unit,
    onNavigateToArticles: () -> Unit,
    onNavigateToGemini: () -> Unit,
    onNavigateToSearch: () -> Unit
) {
    var googleSearchQuery by remember { mutableStateOf("") }
    val focusManager = LocalFocusManager.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        // Background Library Theme Graphic
        Image(
            painter = painterResource(id = R.drawable.bg_library_main),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alpha = 0.28f
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. TOP HEADER FRAME: "مكتبة البدر العامة للدكتور / مالك عبدالرحمن الرميمة"
            MainHeaderFrame()

            Spacer(modifier = Modifier.height(14.dp))

            // 2. GRID OF 6 MAIN DASHBOARD CARDS (2 COLUMNS)
            // ROW 1: [البحث في جوجل] | [نبذه مختصرة عن الدكتور / مالك الرميمة]
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Card 1: Google Search
                GoogleSearchCard(
                    query = googleSearchQuery,
                    onQueryChange = { googleSearchQuery = it },
                    onSearch = {
                        focusManager.clearFocus()
                        repository.openGoogleSearch(googleSearchQuery)
                    },
                    modifier = Modifier.weight(1f)
                )

                // Card 2: Doctor Bio & CV
                DoctorBioCard(
                    onClick = onNavigateToBio,
                    ttsManager = ttsManager,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // ROW 2: [Gemini 3.6 flash] | [كتب ومؤلفات]
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Card 3: Gemini 3.6 Flash
                GeminiAICard(
                    onClick = onNavigateToGemini,
                    modifier = Modifier.weight(1f)
                )

                // Card 4: Books & Publications
                BooksAndPublicationsCard(
                    onClick = onNavigateToBooks,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // ROW 3: [البحث في المكتبة] | [مقالات / روايات / خطب / شعر]
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Card 5: Search in Library
                LibrarySearchCard(
                    onClick = onNavigateToSearch,
                    modifier = Modifier.weight(1f)
                )

                // Card 6: Articles / Novels / Speeches / Poetry
                ArticlesCollectionCard(
                    onClick = onNavigateToArticles,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3. BOTTOM FOOTER FRAME: Golden Design Credit & Direct Call / WhatsApp
            MainFooterFrame(
                onCall = { repository.callDoctor() },
                onWhatsApp = { repository.openWhatsApp() }
            )

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

// ---------------------- HEADER ----------------------
@Composable
fun MainHeaderFrame() {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(16.dp, RoundedCornerShape(16.dp), spotColor = GoldPrimary)
            .testTag("main_header_frame"),
        shape = RoundedCornerShape(16.dp),
        color = GlassSurface.copy(alpha = 0.88f),
        border = BorderStroke(
            1.5.dp,
            Brush.horizontalGradient(listOf(GoldDark, GoldAccent, GoldPrimary, GoldDark))
        )
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.MenuBook, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "مكتبة البدر العامة للدكتور / مالك عبدالرحمن الرميمة",
                    color = GoldLight,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(Icons.Default.Stars, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(20.dp))
            }
        }
    }
}

// ---------------------- CARD 1: GOOGLE SEARCH ----------------------
@Composable
fun GoogleSearchCard(
    query: String,
    onQueryChange: (String) -> Unit,
    onSearch: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .height(200.dp)
            .shadow(10.dp, RoundedCornerShape(18.dp), spotColor = TealAccent)
            .testTag("google_search_card"),
        shape = RoundedCornerShape(18.dp),
        color = GlassSurface.copy(alpha = 0.92f),
        border = BorderStroke(1.2.dp, Brush.verticalGradient(listOf(TealAccent, GoldPrimary.copy(alpha = 0.4f))))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Window Header Bar with Tabs Look
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(modifier = Modifier.size(7.dp).background(CoralRed, CircleShape))
                    Box(modifier = Modifier.size(7.dp).background(GoldAccent, CircleShape))
                    Box(modifier = Modifier.size(7.dp).background(EmeraldGreen, CircleShape))
                }
                Text("البحث في جوجل", color = GoldLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Search input box
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("google_search_input"),
                placeholder = { Text("G  ابحث في Google...", color = TextMuted, fontSize = 11.sp) },
                singleLine = true,
                shape = RoundedCornerShape(20.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyanAccent,
                    unfocusedBorderColor = GlassBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedContainerColor = DarkBackground.copy(alpha = 0.7f),
                    unfocusedContainerColor = DarkBackground.copy(alpha = 0.7f)
                ),
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp)
            )

            // Submit Button
            Button(
                onClick = onSearch,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(38.dp)
                    .testTag("google_search_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Icon(Icons.Default.Search, contentDescription = null, tint = DarkBackground, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("بحث في Google", color = DarkBackground, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }
    }
}

// ---------------------- CARD 2: DOCTOR BIO ----------------------
@Composable
fun DoctorBioCard(
    onClick: () -> Unit,
    ttsManager: TextToSpeechManager,
    modifier: Modifier = Modifier
) {
    val bioSummaryText = "نبذة مختصرة عن الدكتور مالك عبدالرحمن الرميمة، طبيب جراحة الفم والأسنان، باحث إسلامي، مؤلف لـ 17 كتاباً وشاعر."

    Surface(
        onClick = onClick,
        modifier = modifier
            .height(200.dp)
            .shadow(10.dp, RoundedCornerShape(18.dp), spotColor = GoldAccent)
            .testTag("doctor_bio_card"),
        shape = RoundedCornerShape(18.dp),
        color = GlassSurface.copy(alpha = 0.92f),
        border = BorderStroke(1.2.dp, Brush.verticalGradient(listOf(GoldAccent, GoldDark)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Doctor Photo with Golden Badge
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .border(2.dp, GoldAccent, CircleShape)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.dr_malek_photo),
                    contentDescription = "الدكتور مالك الرميمة",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "نبذه مختصرة عن",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
                Text(
                    text = "الدكتور / مالك الرميمة",
                    color = GoldLight,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "طب الأسنان • باحث ومؤلف",
                    color = TealAccent,
                    fontSize = 10.sp
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        ttsManager.speak(bioSummaryText, "bio_card_tts")
                    },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.VolumeUp, contentDescription = "استماع صوتي", tint = GoldAccent, modifier = Modifier.size(18.dp))
                }

                Text(
                    text = "عرض السيرة الذاتية ⬅",
                    color = GoldLight,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ---------------------- CARD 3: GEMINI 3.6 FLASH ----------------------
@Composable
fun GeminiAICard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        modifier = modifier
            .height(200.dp)
            .shadow(12.dp, RoundedCornerShape(18.dp), spotColor = CyanAccent)
            .testTag("gemini_ai_card"),
        shape = RoundedCornerShape(18.dp),
        color = Color(0xFF0F1B2E).copy(alpha = 0.95f),
        border = BorderStroke(
            1.5.dp,
            Brush.linearGradient(listOf(CyanAccent, Color(0xFF9D4EDD), CyanAccent))
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(18.dp))
                Badge(containerColor = Color(0xFF240046)) {
                    Text("AI Assistant", color = CyanAccent, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Gemini 3.6 flash",
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "مساعد الذكاء الاصطناعي للمكتبة الإسلامية والطبية",
                    color = CyanAccent,
                    fontSize = 10.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 14.sp
                )
            }

            Button(
                onClick = onClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(36.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CyanAccent),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("تحدث مع المساعد", color = DarkBackground, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }
    }
}

// ---------------------- CARD 4: BOOKS & PUBLICATIONS ----------------------
@Composable
fun BooksAndPublicationsCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        modifier = modifier
            .height(200.dp)
            .shadow(12.dp, RoundedCornerShape(18.dp), spotColor = GoldPrimary)
            .testTag("books_publications_card"),
        shape = RoundedCornerShape(18.dp),
        color = GlassSurface.copy(alpha = 0.92f),
        border = BorderStroke(1.2.dp, Brush.verticalGradient(listOf(GoldPrimary, GoldDark)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Badge(containerColor = GoldDark) {
                    Text("17 كتاباً", color = GoldLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Icon(Icons.Default.LibraryBooks, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(20.dp))
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "كتب ومؤلفات",
                    color = GoldLight,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "عمل القلوب • مبطلات الطب • المفازة العظمى • وغيرها",
                    color = TextSecondary,
                    fontSize = 9.5.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 13.sp,
                    maxLines = 2
                )
            }

            Button(
                onClick = onClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(36.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("تصفح المكتبة وقراءة", color = DarkBackground, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }
    }
}

// ---------------------- CARD 5: LIBRARY UNIVERSAL SEARCH ----------------------
@Composable
fun LibrarySearchCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        modifier = modifier
            .height(200.dp)
            .shadow(10.dp, RoundedCornerShape(18.dp), spotColor = GoldAccent)
            .testTag("library_search_card"),
        shape = RoundedCornerShape(18.dp),
        color = GlassSurface.copy(alpha = 0.92f),
        border = BorderStroke(1.2.dp, Brush.verticalGradient(listOf(GoldAccent, TealAccent)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(Icons.Default.SavedSearch, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(32.dp))

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "البحث في المكتبة",
                    color = GoldLight,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "بحث فوري وشامل في جميع الكتب والمؤلفات والصفحات",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 13.sp
                )
            }

            Button(
                onClick = onClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(36.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GoldDark),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("فتح البحث الشامل", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }
    }
}

// ---------------------- CARD 6: ARTICLES / NOVELS / SPEECHES / POETRY ----------------------
@Composable
fun ArticlesCollectionCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        modifier = modifier
            .height(200.dp)
            .shadow(10.dp, RoundedCornerShape(18.dp), spotColor = TealAccent)
            .testTag("articles_collection_card"),
        shape = RoundedCornerShape(18.dp),
        color = GlassSurface.copy(alpha = 0.92f),
        border = BorderStroke(1.2.dp, Brush.verticalGradient(listOf(TealAccent, Color(0xFF3A86FF))))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Edit, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                Icon(Icons.Default.AutoStories, contentDescription = null, tint = CoralRed, modifier = Modifier.size(16.dp))
                Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(16.dp))
                Icon(Icons.Default.MusicNote, contentDescription = null, tint = TealAccent, modifier = Modifier.size(16.dp))
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "مقالات / روايات",
                    color = GoldLight,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "خطب / شعر",
                    color = TealAccent,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "رواية حديقة السلام • ديوان الشعر",
                    color = TextMuted,
                    fontSize = 9.sp,
                    maxLines = 1
                )
            }

            Button(
                onClick = onClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(36.dp),
                colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("تصفح الأعمال الأدبية", color = DarkBackground, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }
    }
}

// ---------------------- FOOTER ----------------------
@Composable
fun MainFooterFrame(
    onCall: () -> Unit,
    onWhatsApp: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(16.dp, RoundedCornerShape(16.dp), spotColor = GoldPrimary)
            .testTag("main_footer_frame"),
        shape = RoundedCornerShape(16.dp),
        color = GlassSurface.copy(alpha = 0.94f),
        border = BorderStroke(
            1.5.dp,
            Brush.horizontalGradient(listOf(GoldDark, GoldAccent, GoldPrimary, GoldDark))
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "تصميم وبرمجة الدكتور/ مالك عبدالرحمن الرميمة",
                color = GoldLight,
                fontSize = 14.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "للتواصل والاستشارات: ",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Text(
                    text = "771134103",
                    color = GoldAccent,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Active Action Buttons for Phone & WhatsApp
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ElevatedButton(
                    onClick = onCall,
                    modifier = Modifier.weight(1f).testTag("footer_call_btn"),
                    colors = ButtonDefaults.elevatedButtonColors(
                        containerColor = GoldDark,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(18.dp), tint = GoldLight)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("هاتف", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                ElevatedButton(
                    onClick = onWhatsApp,
                    modifier = Modifier.weight(1f).testTag("footer_whatsapp_btn"),
                    colors = ButtonDefaults.elevatedButtonColors(
                        containerColor = EmeraldGreen,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("واتس اب", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}
