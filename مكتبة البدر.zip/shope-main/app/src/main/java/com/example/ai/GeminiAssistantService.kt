package com.example.ai

import com.example.BuildConfig
import com.example.data.BooksDataSource
import com.example.data.ArticlesDataSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
) {
    val isUser: Boolean get() = sender == MessageSender.USER
}

enum class MessageSender {
    USER,
    GEMINI
}

class GeminiAssistantService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val _messages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = MessageSender.GEMINI,
                text = "مرحباً بك في مكتبة البدر العامة للدكتور مالك عبدالرحمن الرميمة! أنا مساعدك الذكي Gemini 3.6 Flash، جاهز للإجابة على جميع استفساراتك حول مؤلفات الدكتور وكتبه الـ 17 ومقالاته وسيرته الذاتية ومختلف العلوم الإسلامية والطبية."
            )
        )
    )
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val systemPrompt = """
        أنت المساعد الذكي "Gemini 3.6 Flash" في تطبيق "مكتبة البدر العامة للدكتور مالك عبدالرحمن الرميمة".
        أنت تقدم إجابات راقية، علمية، إسلامية، طبية، وأدبية مستندة إلى روح ومؤلفات وفكر الدكتور مالك عبدالرحمن الرميمة (طبيب جراحة الفم والأسنان، باحث إسلامي، شاعر ومؤلف).
        معلومات عن الدكتور مالك:
        - الاسم: الدكتور مالك عبدالرحمن عبد الولي الرميمة
        - هاتف وواتساب: 771134103
        - التخصص: بكالوريوس طب وجراحة الفم والأسنان جامعة ذمار (2011-2012م)، خبرة واسعة في طب الأسنان والتدريس الأكاديمي، وباحث ومؤلف لـ 17 كتاباً في العلوم الإسلامية والطبية والتربوية والشعر.
        - من أهم مؤلفاته: كتاب عمل القلوب، مبطلات الطب، أثر الفكر الغربي المعاصر، إلى المفازة العظمى، طبيبك المنزلي، ابدأ من الصفر، استكفي مما تزرع، آيات قرآنية في الأرزاق الربانية، جند الله في السماوات والأرض، دع السقم، سباعية النشأة، ظلم الشعوب المسلمة تحت شعار الوطنية، عمى القلوب، وللشعر حلاوة كحلاوة السكر، مزامير من حكم، نفحات من آية الكرسي، نواميس في محراب الرحمن، ورواية حديقة السلام.
        
        كن لبقاً، حكيماً، معتزاً باللغة العربية الفصحى والقيم الإسلامية السمحة، وقدم الإجابات الشافية والمفيدة لكل سائل.
    """.trimIndent()

    suspend fun sendMessage(userText: String) {
        if (userText.isBlank()) return
        val userMsg = ChatMessage(sender = MessageSender.USER, text = userText.trim())
        _messages.value = _messages.value + userMsg
        _isLoading.value = true

        val responseText = askGemini(userText, _messages.value)
        val geminiMsg = ChatMessage(sender = MessageSender.GEMINI, text = responseText)
        _messages.value = _messages.value + geminiMsg
        _isLoading.value = false
    }

    fun clearChat() {
        _messages.value = listOf(
            ChatMessage(
                sender = MessageSender.GEMINI,
                text = "تم مسح المحادثة. أهلاً بك مجدداً في مكتبة البدر للدكتور مالك الرميمة!"
            )
        )
    }

    private suspend fun askGemini(prompt: String, conversationHistory: List<ChatMessage>): String {
        return withContext(Dispatchers.IO) {
            val apiKey = try {
                BuildConfig.GEMINI_API_KEY
            } catch (e: Exception) {
                ""
            }

            if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
                try {
                    val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"
                    
                    val contentsArray = JSONArray()
                    
                    // Add previous context
                    for (msg in conversationHistory.takeLast(6)) {
                        val role = if (msg.sender == MessageSender.USER) "user" else "model"
                        val partObj = JSONObject().put("text", msg.text)
                        val contentObj = JSONObject()
                            .put("role", role)
                            .put("parts", JSONArray().put(partObj))
                        contentsArray.put(contentObj)
                    }

                    val systemInstruction = JSONObject()
                        .put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))

                    val requestBodyJson = JSONObject()
                        .put("system_instruction", systemInstruction)
                        .put("contents", contentsArray)

                    val mediaType = "application/json; charset=utf-8".toMediaType()
                    val requestBody = requestBodyJson.toString().toRequestBody(mediaType)

                    val request = Request.Builder()
                        .url(url)
                        .post(requestBody)
                        .build()

                    val response = client.newCall(request).execute()
                    val responseBody = response.body?.string() ?: ""

                    if (response.isSuccessful && responseBody.isNotBlank()) {
                        val jsonResponse = JSONObject(responseBody)
                        val candidates = jsonResponse.optJSONArray("candidates")
                        if (candidates != null && candidates.length() > 0) {
                            val candidate = candidates.getJSONObject(0)
                            val content = candidate.getJSONObject("content")
                            val parts = content.getJSONArray("parts")
                            if (parts.length() > 0) {
                                return@withContext parts.getJSONObject(0).getString("text")
                            }
                        }
                    }
                } catch (e: Exception) {
                    // Fall back to intelligent local assistant
                }
            }

            // Fallback Intelligent Knowledge Engine
            return@withContext generateLocalResponse(prompt)
        }
    }

    private fun generateLocalResponse(query: String): String {
        val q = query.trim().lowercase()

        return when {
            q.contains("سيرة") || q.contains("من هو") || q.contains("الدكتور") || q.contains("مالك") -> {
                "الدكتور مالك عبدالرحمن عبدالولي الرميمة هو طبيب جراحة الفم والأسنان، متخرج من جامعة ذمار (2011-2012م)، حاصل على ICDL بامتياز وشهادات مؤتمرات IDEC 2024 و 2025 و Rogin لجذور الأسنان. قام بالتدريس في جامعات تعز، السعيد، الوطنية، الحكمة، والعطاء، وعمل رئيساً لقسم الأسنان بمستشفى المظفر ومركز الناصر وعيادة الرحمن. وهو باحث ومؤلف لـ 17 كتاباً بارزاً وشاعر وأديب."
            }
            q.contains("عمل القلوب") -> {
                "كتاب «عمل القلوب وأسرار الإيمان» من أروع كتب الدكتور مالك الرميمة، يتناول أعمال القلوب كالإخلاص واليقين والتوكل والصبر والرجاء والمحبة، وكيف أنها أصل صلاح الجوارح ومفتاح النجاة في الدنيا والآخرة."
            }
            q.contains("مبطلات الطب") -> {
                "كتاب «مبطلات الطب» يناقش الممارسات الطبية الخاطئة والشبهات الشائعة، ويوضح الجمع الرصين بين الطب النبوي الروحي والطب الحديث التجريبي القائم على الدليل العلمي."
            }
            q.contains("المفازة") -> {
                "كتاب «إلى المفازة العظمى» دليل إيماني وتربوي نحو الفلاح الأكبر والنجاة يوم القيامة، مع بيان معالم الطريق المستقيم وثبات المسلم في زمن الفتن."
            }
            q.contains("طبيبك") -> {
                "كتاب «طبيبك المنزلي» مرجع صحي وتوعوي للعائلة يجمع بين الإرشادات الوقائية لصحة الفم والأسنان والجسم، والتعامل مع الطوارئ المنزلية بحكمة علمية."
            }
            q.contains("حديقة السلام") || q.contains("رواية") -> {
                "رواية «حديقة السلام» للأديب الدكتور أبا أنس (مالك الرميمة) عمل أدبي رائع يمزج بين الحكمة والموعظة والروح الإيمانية بأسلوب قصصي مشوق يلامس القلوب."
            }
            q.contains("كتب") || q.contains("مؤلفات") || q.contains("كم كتاب") -> {
                "ألف الدكتور مالك الرميمة 17 كتاباً ومؤلفاً متاحين بالكامل داخل التطبيق:\n1. عمل القلوب\n2. مبطلات الطب\n3. أثر الفكر الغربي المعاصر\n4. إلى المفازة العظمى\n5. طبيبك المنزلي\n6. ابدأ من الصفر\n7. استكفي مما تزرع\n8. آيات قرآنية في الأرزاق\n9. جند الله في السماوات والأرض\n10. دع السقم\n11. سباعية النشأة\n12. ظلم الشعوب المسلمة\n13. عمى القلوب\n14. وللشعر حلاوة كحلاوة السكر\n15. مزامير من حكم\n16. نفحات من آية الكرسي\n17. نواميس في محراب الرحمن."
            }
            q.contains("هاتف") || q.contains("تواصل") || q.contains("واتس") || q.contains("رقم") -> {
                "يمكنك التواصل المباشر مع الدكتور مالك عبدالرحمن الرميمة عبر الهاتف والواتساب على الرقم: 771134103، أو عبر الأزرار المباشرة في أسفل الصفحة الرئيسية."
            }
            else -> {
                "أهلاً بك! يمكنك استكشاف كتب ومؤلفات الدكتور مالك الـ 17، ورواية حديقة السلام، وديوان الشعر والمقالات والخطب في أقسام التطبيق، أو الاستماع إليها عبر المتكلم الصوتي التلقائي."
            }
        }
    }
}
