package com.example.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.model.ArticleItem
import com.example.model.Book
import com.example.model.SearchResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class LibraryRepository(private val context: Context) {

    private val _books = MutableStateFlow<List<Book>>(BooksDataSource.booksList)
    val books: StateFlow<List<Book>> = _books.asStateFlow()

    private val _articles = MutableStateFlow<List<ArticleItem>>(ArticlesDataSource.articlesList)
    val articles: StateFlow<List<ArticleItem>> = _articles.asStateFlow()

    fun addNewBook(book: Book) {
        _books.value = _books.value + book
    }

    fun addNewArticle(article: ArticleItem) {
        _articles.value = _articles.value + article
    }

    fun getBookById(id: String): Book? {
        return _books.value.find { it.id == id }
    }

    fun getArticleById(id: String): ArticleItem? {
        return _articles.value.find { it.id == id }
    }

    fun searchAll(query: String): List<SearchResult> = searchLibrary(query)

    fun searchLibrary(query: String): List<SearchResult> {
        if (query.isBlank()) return emptyList()
        val q = query.trim().lowercase()
        val results = mutableListOf<SearchResult>()

        // Search Books
        for (book in _books.value) {
            if (book.title.lowercase().contains(q) || book.description.lowercase().contains(q) || book.subtitle.lowercase().contains(q)) {
                results.add(
                    SearchResult(
                        title = book.title,
                        snippet = book.description.take(160) + "...",
                        sourceTitle = "كتاب: ${book.title}",
                        category = book.category,
                        bookId = book.id
                    )
                )
            }
            // Search Book Pages
            for (page in book.pages) {
                if (page.content.lowercase().contains(q) || page.title.lowercase().contains(q)) {
                    val index = page.content.lowercase().indexOf(q)
                    val start = maxOf(0, index - 30)
                    val end = minOf(page.content.length, index + 100)
                    val snippet = "..." + page.content.substring(start, end).replace("\n", " ") + "..."
                    results.add(
                        SearchResult(
                            title = "${book.title} - ${page.title}",
                            snippet = snippet,
                            sourceTitle = "صفحة ${page.pageNumber}: ${page.title}",
                            category = book.category,
                            bookId = book.id,
                            pageNumber = page.pageNumber
                        )
                    )
                }
            }
        }

        // Search Articles, Novels, Poems, Speeches
        for (article in _articles.value) {
            if (article.title.lowercase().contains(q) || article.content.lowercase().contains(q) || article.summary.lowercase().contains(q)) {
                val snippet = if (article.content.lowercase().contains(q)) {
                    val index = article.content.lowercase().indexOf(q)
                    val start = maxOf(0, index - 30)
                    val end = minOf(article.content.length, index + 100)
                    "..." + article.content.substring(start, end).replace("\n", " ") + "..."
                } else {
                    article.summary
                }
                results.add(
                    SearchResult(
                        title = "${article.type.titleArabic}: ${article.title}",
                        snippet = snippet,
                        sourceTitle = article.title,
                        category = article.type.titleArabic,
                        articleId = article.id
                    )
                )
            }
        }

        return results
    }

    // Direct Google Search integration
    fun openGoogleSearch(query: String) {
        val url = if (query.isBlank()) {
            "https://www.google.com"
        } else {
            "https://www.google.com/search?q=" + Uri.encode(query.trim())
        }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            // Log or ignore
        }
    }

    // Direct Phone Call
    fun callDoctor(phone: String = "771134103") {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            // Log or ignore
        }
    }

    // Direct WhatsApp Message
    fun openWhatsApp(phone: String = "771134103") {
        val formattedNumber = if (phone.startsWith("+") || phone.startsWith("967")) {
            phone.replace("+", "")
        } else {
            "967$phone"
        }
        val url = "https://api.whatsapp.com/send?phone=$formattedNumber&text=" + Uri.encode("السلام عليكم ورحمة الله وبركاته يا دكتور مالك، تواصلت معك عبر تطبيق مكتبة البدر.")
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            // If whatsapp intent fails, open browser whatsapp link
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$formattedNumber")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(browserIntent)
        }
    }
}
