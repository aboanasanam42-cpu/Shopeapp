package com.example.model

data class Book(
    val id: String,
    val title: String,
    val subtitle: String = "",
    val category: String,
    val date: String = "",
    val description: String,
    val phone: String = "771134103",
    val author: String = "الدكتور مالك عبدالرحمن الرميمة",
    val dedication: String = "",
    val indexList: List<String> = emptyList(),
    val pages: List<BookPage> = emptyList(),
    val isCustom: Boolean = false
)

data class BookPage(
    val pageNumber: Int,
    val title: String = "",
    val content: String
)

data class ArticleItem(
    val id: String,
    val title: String,
    val type: ArticleType,
    val date: String = "",
    val author: String = "الدكتور مالك عبدالرحمن الرميمة",
    val summary: String,
    val content: String,
    val isCustom: Boolean = false
) {
    val description: String get() = summary
}

enum class ArticleType(val titleArabic: String) {
    ARTICLE("مقالة"),
    NOVEL("رواية"),
    SPEECH("خطبة"),
    POETRY("شعر")
}

data class SearchResult(
    val title: String,
    val snippet: String,
    val sourceTitle: String,
    val category: String,
    val bookId: String? = null,
    val pageNumber: Int? = null,
    val articleId: String? = null
)
