package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.TextToSpeechManager
import com.example.data.LibraryRepository
import com.example.model.SearchResult
import com.example.ui.components.AudioSpeakerButton
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibrarySearchScreen(
    repository: LibraryRepository,
    ttsManager: TextToSpeechManager,
    onNavigateToBook: (String, Int) -> Unit,
    onNavigateToArticle: (String) -> Unit,
    onBack: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val searchResults = remember(searchQuery) {
        repository.searchAll(searchQuery)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "البحث الشامل في المكتبة",
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("search_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع", tint = GoldPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 14.dp)
        ) {
            // Big Search Box
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp)
                    .testTag("universal_search_input"),
                placeholder = { Text("اكتب أي كلمة، عبارة، أو موضوع للبحث...", color = TextMuted, fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.SavedSearch, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(26.dp)) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "مسح", tint = TextMuted)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = GlassBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface
                )
            )

            // Results count
            if (searchQuery.isNotBlank()) {
                Text(
                    text = "تم العثور على ${searchResults.size} نتيجة لـ \"$searchQuery\":",
                    color = GoldLight,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            } else {
                Text(
                    text = "اكتب كلمة للبحث في نصوص الـ 17 كتاباً والمقالات والروايات والخطب والقصائد:",
                    color = TextMuted,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }

            // Results List
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(searchResults) { result ->
                    SearchResultCard(
                        result = result,
                        ttsManager = ttsManager,
                        onClick = {
                            if (result.bookId != null) {
                                onNavigateToBook(result.bookId, result.pageNumber ?: 1)
                            } else if (result.articleId != null) {
                                onNavigateToArticle(result.articleId)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun SearchResultCard(
    result: SearchResult,
    ttsManager: TextToSpeechManager,
    onClick: () -> Unit
) {
    val isBook = result.bookId != null

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("search_result_${result.title}"),
        borderGlowColor = if (isBook) GoldPrimary else TealAccent,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Badge(containerColor = if (isBook) GoldDark else TealAccent) {
                Text(
                    text = if (isBook) "كتاب (ص ${result.pageNumber ?: 1})" else "مقالة / أدب",
                    color = if (isBook) GoldLight else DarkBackground,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }

            Text(
                text = result.title,
                color = GoldLight,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = result.snippet,
            color = TextSecondary,
            fontSize = 12.sp,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
            lineHeight = 17.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            AudioSpeakerButton(
                textToRead = "${result.title}. ${result.snippet}",
                ttsManager = ttsManager,
                label = "استماع للمقطع"
            )

            Text(
                text = "انتقال إلى الموضع ⬅",
                color = if (isBook) GoldPrimary else TealAccent,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
