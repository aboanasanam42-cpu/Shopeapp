package com.alromimah.mexcbot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
