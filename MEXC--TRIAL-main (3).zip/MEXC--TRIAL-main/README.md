# MEXC--TRIAL
name: alromimah_mexc_bot description: Cloud Trading Bot for MEXC Futures Contracts. version: 1.0.0+1  environment:   sdk: '>=3.0.0 &lt;4.0.0'  dependencies:   flutter:     sdk: flutter   cupertino_icons: ^1.0.5   http: ^1.1.0                # للاتصال بواجهة برمجة تطبيقات MEXC   
