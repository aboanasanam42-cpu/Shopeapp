import 'package:flutter/material.dart';
import 'mexc_api_service.dart';

void main() {
  runApp(const MexcBotApp());
}

class MexcBotApp extends StatelessWidget {
  const MexcBotApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Alromimah Mexc Bot',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        brightness: Brightness.dark, // واجهة داكنة تناسب منصات التداول
      ),
      home: const TradingBotDashboard(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class TradingBotDashboard extends StatefulWidget {
  const TradingBotDashboard({Key? key}) : super(key: key);

  @override
  State<TradingBotDashboard> createState() => _TradingBotDashboardState();
}

class _TradingBotDashboardState extends State<TradingBotDashboard> {
  // الحقول المطلوبة بالملف لإدخال حجم الصفقة، الرافعة، والمبلغ
  final TextEditingController _sizeController = TextEditingController();
  final TextEditingController _leverageController = TextEditingController();
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _ownerKeyController = TextEditingController();

  final MexcApiService _apiService = MexcApiService();
  bool _isCloudTradingActive = false; // حالة البوت السحابي

  // مفاتيح افتراضية مشفرة لـ API داخل الكود، ويتم تفعيلها عبر حقل المالك
  final String _encryptedApiKey = "YOUR_MEXC_API_KEY_HERE";
  final String _encryptedSecretKey = "YOUR_MEXC_SECRET_KEY_HERE";

  void _toggleCloudTrading() {
    // التحقق من حقل "أنا مالك البوت" لتفعيل التداول
    if (_ownerKeyController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('الرجاء إدخال رمز التحقق (أنا مالك البوت) أولاً!')),
      );
      return;
    }

    setState(() {
      _isCloudTradingActive = !_isCloudTradingActive;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_isCloudTradingActive 
            ? 'تم تفعيل البوت السحابي وتتبع الصفقات الحية بنجاح' 
            : 'موقوف - البوت في وضع الاستعداد الآن'),
        backgroundColor: _isCloudTradingActive ? Colors.green : Colors.red,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('لوحة تداول بوت Alromimah السحابي'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment: CrossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // حقل إثبات ملكية البوت (المطلوب لحماية الـ API الخاص بك)
              Card(
                color: Colors.blueGrey[900],
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: TextField(
                    controller: _ownerKeyController,
                    decoration: const InputDecoration(
                      labelText: 'حقل: أنا مالك البوت (أدخل رمز المرور الخاص بك لتفعيل المفاتيح)',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.security),
                    ),
                    obscureText: true,
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // حقول المدخلات الثلاثة الفارغة المطلوبة بالصفحة
              TextField(
                controller: _sizeController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'حجم الصفقة (Trade Size)',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.bar_chart),
                ),
              ),
              const SizedBox(height: 15),
              TextField(
                controller: _leverageController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'الرافعة المالية (Leverage) مثلاً: 20x',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.speed),
                ),
              ),
              const SizedBox(height: 15),
              TextField(
                controller: _amountController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'مبلغ الدخول لكل صفقة (Amount per Trade) $',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.attach_money),
                ),
              ),
              const SizedBox(height: 30),

              // زر التفعيل السحابي المباشر للبوت
              ElevatedButton.icon(
                onPressed: _toggleCloudTrading,
                icon: Icon(_isCloudTradingActive ? Icons.stop : Icons.play_arrow),
                label: Text(
                  _isCloudTradingActive ? 'إيقاف البوت السحابي' : 'تفعيل التداول للبوت السحابي',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  backgroundColor: _isCloudTradingActive ? Colors.red[700] : Colors.green[700],
                ),
              ),
              const SizedBox(height: 20),

              // مؤشر حالة الحساب والربح المتوقع المورد للمحفظة
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildStatusCard("حالة التداول", _isCloudTradingActive ? "نشط سحابياً" : "متوقف"),
                  _buildStatusCard("الربح الصافي المورد", "تحديث تلقائي..."),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatusCard(String title, String value) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
        child: Column(
          children: [
            Text(title, style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 5),
            Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}
