import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:crypto/crypto.dart';

class MexcApiService {
  final String baseUrl = "https://contract.mexc.com"; // رابط العقود الآجلة لمنصة MEXC
  
  // دالة لتوليد التوقيع الرقمي الآمن المطلوب من المنصة
  String _createSignature(String secretKey, String queryParams) {
    var bytes = utf8.encode(queryParams);
    var key = utf8.encode(secretKey);
    var hmacSha256 = Hmac(sha256, key);
    var digest = hmacSha256.convert(bytes);
    return digest.toString();
  }

  // دالة تنفيذ صفقة عقود آجلة بناءً على المدخلات الخاصة بك
  Future<bool> placeFuturesOrder({
    required String apiKey,
    required String secretKey,
    required String symbol,
    required String leverage,
    required double positionSize,
    required double amountPerTrade,
  }) async {
    final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
    
    // إعداد متغيرات الصفقة السحابية
    final Map<String, String> params = {
      "symbol": symbol,
      "leverage": leverage,
      "vol": positionSize.toString(),
      "side": "1", // 1 للشراء (Open Long) كمثال
      "type": "1", // أمر سوق (Market Order) للتنفيذ اللحظي السريع
      "timestamp": timestamp,
    };

    String queryString = Uri(queryParameters: params).query;
    String signature = _createSignature(secretKey, queryString);
    
    final String url = "$baseUrl/api/v1/private/order/submit?$queryString&signature=$signature";

    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {
          "ApiKey": apiKey,
          "Content-Type": "application/json",
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['code'] == 0; // 0 يعني نجاح العملية في MEXC
      }
      return false;
    } catch (e) {
      return false;
    }
  }
}
